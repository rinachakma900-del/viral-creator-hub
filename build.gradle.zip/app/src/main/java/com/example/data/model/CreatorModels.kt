package com.example.data.model

data class CreatorSocialLink(
    val id: String,
    val title: String,
    val platformName: String,
    val url: String,
    val handle: String,
    val description: String,
    val badgeText: String,
    val primaryColorHex: Long
)

data class AiChatMessage(
    val id: String,
    val text: String,
    val isUser: Boolean,
    val timestamp: Long = System.currentTimeMillis()
)

data class ViralTip(
    val id: String,
    val title: String,
    val category: String,
    val description: String,
    val fullGuide: String,
    val actionLabel: String = "কপি ও শেয়ার করুন"
)

data class ViralScriptTemplate(
    val id: String,
    val title: String,
    val type: String,
    val hook: String,
    val body: String,
    val cta: String,
    val hashtags: String
)

// === Monetization Models ===

data class WalletBalance(
    val availableBdt: Double,
    val pendingBdt: Double,
    val lifetimeBdt: Double,
    val availableUsd: Double,
    val pendingUsd: Double,
    val lifetimeUsd: Double
)

data class EarningSource(
    val id: String,
    val title: String,
    val subtitle: String,
    val amountBdt: Double,
    val percentage: Float,
    val colorHex: Long
)

enum class WithdrawalStatus(val label: String, val colorHex: Long) {
    COMPLETED("সফল (Completed)", 0xFF80E1A7),
    PROCESSING("প্রসেসিং (In Progress)", 0xFFFFB300),
    PENDING("পেন্ডিং (Under Review)", 0xFF64B5F6)
}

data class WithdrawalMethod(
    val id: String,
    val name: String,
    val feePercent: String,
    val minAmountBdt: Double,
    val processingTime: String,
    val placeholder: String,
    val colorHex: Long
)

data class WithdrawalTransaction(
    val id: String,
    val date: String,
    val method: String,
    val accountInfo: String,
    val amountBdt: Double,
    val status: WithdrawalStatus,
    val transactionRef: String
)

data class SponsoredCampaign(
    val id: String,
    val brandName: String,
    val title: String,
    val payoutBdt: Double,
    val category: String,
    val spotsLeft: Int,
    val deadline: String,
    val requirements: String,
    val isApplied: Boolean = false
)

data class PremiumSubscriptionTier(
    val id: String,
    val title: String,
    val priceBdt: Double,
    val billingCycle: String,
    val activeSubscribers: Int,
    val perks: List<String>,
    val isEnabled: Boolean = true
)

data class CreatorMilestoneReward(
    val id: String,
    val title: String,
    val targetViews: String,
    val rewardBdt: Double,
    val progressPercent: Float,
    val isClaimed: Boolean = false
)

// === AI Content Generator Models ===

data class TrendingTopicSuggestion(
    val id: String,
    val title: String,
    val category: String,
    val viralPotential: String,
    val whyItWorks: String,
    val positiveAngle: String
)

data class GeneratedAiContent(
    val id: String,
    val topic: String,
    val platform: String,
    val hook: String,
    val videoScript: String,
    val caption: String,
    val hashtags: String,
    val positiveImpactScore: Int = 98,
    val helpfulTips: String
)

// === Content Discovery Models ===

enum class SocialPlatform(val displayName: String, val colorHex: Long, val tag: String) {
    TIKTOK("TikTok Lite", 0xFFFF0050, "tiktok"),
    YOUTUBE("YouTube", 0xFFFF0000, "youtube"),
    FACEBOOK("Facebook", 0xFF1877F2, "facebook"),
    TELEGRAM("Telegram", 0xFF2AABEE, "telegram")
}

data class DiscoveryContentItem(
    val id: String,
    val platform: SocialPlatform,
    val title: String,
    val creatorName: String,
    val creatorHandle: String,
    val viewsCount: String,
    val likesCount: String,
    val viralityScore: Int,
    val targetUrl: String,
    val category: String,
    val sampleHook: String,
    val tags: List<String>
)
