package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.AdsClick
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.outlined.AccountBalanceWallet
import androidx.compose.material.icons.outlined.AdsClick
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.MonetizationOn
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.ViralViewModel
import com.example.ui.screens.AdMobSettingsScreen
import com.example.ui.screens.AiAssistantScreen
import com.example.ui.screens.EarningToolsScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.theme.ElegantDarkBackground
import com.example.ui.theme.ElegantDarkBorder
import com.example.ui.theme.ElegantDarkPrimary
import com.example.ui.theme.ElegantDarkPrimaryContainer
import com.example.ui.theme.ElegantDarkSurface
import com.example.ui.theme.ElegantDarkText
import com.example.ui.theme.ElegantDarkTextMuted
import com.example.ui.theme.MyApplicationTheme

enum class NavTab(
    val title: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val testTag: String
) {
    HOME("হোম ও ট্রেন্ড", Icons.Filled.Home, Icons.Outlined.Home, "nav_tab_home"),
    AI_ASSISTANT("এআই স্টুডিও", Icons.Filled.AutoAwesome, Icons.Outlined.AutoAwesome, "nav_tab_ai"),
    EARNING("আয় ও ওয়ালেট", Icons.Filled.AccountBalanceWallet, Icons.Outlined.AccountBalanceWallet, "nav_tab_earning"),
    ADMOB("অ্যাডমব", Icons.Filled.AdsClick, Icons.Outlined.AdsClick, "nav_tab_admob")
}

class MainActivity : ComponentActivity() {

    private val viewModel: ViralViewModel by viewModels()

    @OptIn(ExperimentalMaterial3Api::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                val context = LocalContext.current
                var currentTab by remember { mutableStateOf(NavTab.HOME) }
                val bannerAdUnitId by viewModel.bannerAdUnitId.collectAsState()
                val isTestMode by viewModel.isAdTestMode.collectAsState()

                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    topBar = {
                        CenterAlignedTopAppBar(
                            title = {
                                Text(
                                    text = when (currentTab) {
                                        NavTab.HOME -> "Viral Creator Hub"
                                        NavTab.AI_ASSISTANT -> "AI কন্টেন্ট স্টুডিও"
                                        NavTab.EARNING -> "আয়, স্পনসর ও ওয়ালেট"
                                        NavTab.ADMOB -> "Google AdMob সেটিংস"
                                    },
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = ElegantDarkText
                                )
                            },
                            actions = {
                                IconButton(
                                    onClick = {
                                        viewModel.shareText(
                                            context,
                                            "Viral Creator Hub",
                                            "চাকমা মিউজিক ভিডিও ও ভাইরাল কনটেন্ট হাব:\nইউটিউব: https://www.youtube.com/@Chakma-music-Video\nটিকটক: https://vm.tiktok.com/ZSVw2r989/\nটেলিগ্রাম: https://t.me/boost/JuwelChakma989"
                                        )
                                    },
                                    modifier = Modifier.testTag("btn_top_share")
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Share,
                                        contentDescription = "Share",
                                        tint = ElegantDarkText
                                    )
                                }
                            },
                            colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                                containerColor = ElegantDarkBackground
                            )
                        )
                    },
                    bottomBar = {
                        NavigationBar(
                            containerColor = ElegantDarkSurface,
                            tonalElevation = 0.dp,
                            modifier = Modifier
                                .border(
                                    androidx.compose.foundation.BorderStroke(1.dp, ElegantDarkBorder)
                                )
                                .testTag("main_bottom_nav")
                        ) {
                            NavTab.entries.forEach { tab ->
                                val isSelected = currentTab == tab
                                NavigationBarItem(
                                    selected = isSelected,
                                    onClick = { currentTab = tab },
                                    icon = {
                                        Icon(
                                            imageVector = if (isSelected) tab.selectedIcon else tab.unselectedIcon,
                                            contentDescription = tab.title,
                                            modifier = Modifier.size(22.dp)
                                        )
                                    },
                                    label = {
                                        Text(
                                            text = tab.title,
                                            fontSize = 11.sp,
                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                        )
                                    },
                                    colors = NavigationBarItemDefaults.colors(
                                        selectedIconColor = Color(0xFF381E72),
                                        selectedTextColor = ElegantDarkPrimary,
                                        indicatorColor = ElegantDarkPrimary,
                                        unselectedIconColor = ElegantDarkTextMuted,
                                        unselectedTextColor = ElegantDarkTextMuted
                                    ),
                                    modifier = Modifier.testTag(tab.testTag)
                                )
                            }
                        }
                    }
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(ElegantDarkBackground)
                            .padding(innerPadding)
                    ) {
                        AnimatedContent(
                            targetState = currentTab,
                            transitionSpec = { fadeIn() togetherWith fadeOut() },
                            label = "screen_transition"
                        ) { targetTab ->
                            when (targetTab) {
                                NavTab.HOME -> HomeScreen(
                                    viewModel = viewModel,
                                    bannerAdUnitId = bannerAdUnitId,
                                    isTestMode = isTestMode,
                                    onNavigateToAi = { currentTab = NavTab.AI_ASSISTANT },
                                    onNavigateToEarning = { currentTab = NavTab.EARNING }
                                )
                                NavTab.AI_ASSISTANT -> AiAssistantScreen(
                                    viewModel = viewModel,
                                    bannerAdUnitId = bannerAdUnitId,
                                    isTestMode = isTestMode
                                )
                                NavTab.EARNING -> EarningToolsScreen(
                                    viewModel = viewModel,
                                    bannerAdUnitId = bannerAdUnitId,
                                    isTestMode = isTestMode
                                )
                                NavTab.ADMOB -> AdMobSettingsScreen(
                                    viewModel = viewModel
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

