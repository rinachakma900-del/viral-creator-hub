package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AdsClick
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.ViralViewModel
import com.example.ui.components.AdMobBannerView
import com.example.ui.theme.ElegantDarkAccentGreen
import com.example.ui.theme.ElegantDarkBorder
import com.example.ui.theme.ElegantDarkPrimary
import com.example.ui.theme.ElegantDarkSurface
import com.example.ui.theme.ElegantDarkSurfaceVariant
import com.example.ui.theme.ElegantDarkText
import com.example.ui.theme.ElegantDarkTextMuted

@Composable
fun AdMobSettingsScreen(
    viewModel: ViralViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val currentBannerAdUnitId by viewModel.bannerAdUnitId.collectAsState()
    val isTestMode by viewModel.isAdTestMode.collectAsState()
    var inputAdUnitId by remember(currentBannerAdUnitId) { mutableStateOf(currentBannerAdUnitId) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("admob_settings_screen"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Header Card
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(20.dp))
                    .border(1.dp, ElegantDarkBorder, RoundedCornerShape(20.dp))
                    .testTag("admob_header_card"),
                colors = CardDefaults.cardColors(
                    containerColor = ElegantDarkSurface
                )
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(44.dp)
                                .clip(CircleShape)
                                .background(ElegantDarkAccentGreen.copy(alpha = 0.15f))
                                .border(1.dp, ElegantDarkAccentGreen.copy(alpha = 0.3f), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.AdsClick,
                                contentDescription = "AdMob",
                                tint = ElegantDarkAccentGreen,
                                modifier = Modifier.size(24.dp)
                            )
                        }

                        Spacer(modifier = Modifier.width(12.dp))

                        Column {
                            Text(
                                text = "গুগল AdMob ইন্টিগ্রেশন ও সেটিংস",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = ElegantDarkText
                            )
                            Text(
                                text = "ব্যানার অ্যাড ইউনিট আইডি ও লাইভ মনিটাইজেশন কন্ট্রোল",
                                fontSize = 11.sp,
                                color = ElegantDarkTextMuted
                            )
                        }
                    }
                }
            }
        }

        // Live Banner Preview
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(18.dp))
                    .border(1.dp, ElegantDarkBorder, RoundedCornerShape(18.dp))
                    .testTag("banner_preview_card"),
                colors = CardDefaults.cardColors(
                    containerColor = ElegantDarkSurface
                )
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "লাইভ ব্যানার প্রিভিউ:",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = ElegantDarkText
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    AdMobBannerView(
                        adUnitId = currentBannerAdUnitId,
                        isTestMode = isTestMode
                    )
                }
            }
        }

        // Banner Ad Unit ID Configuration Card
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(18.dp))
                    .border(1.dp, ElegantDarkBorder, RoundedCornerShape(18.dp))
                    .testTag("ad_unit_id_card"),
                colors = CardDefaults.cardColors(
                    containerColor = ElegantDarkSurface
                )
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Key,
                            contentDescription = null,
                            tint = ElegantDarkPrimary,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "আপনার Banner Ad Unit ID বসান",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = ElegantDarkText
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "গুগল অ্যাডমব কনসোল থেকে তৈরি করা ব্যানার বিজ্ঞাপন ইউনিট আইডি (e.g. ca-app-pub-XXXXXXXXXXXXXXXX/YYYYYYYYYY) এখানে পেস্ট করুন।",
                        fontSize = 12.sp,
                        color = ElegantDarkTextMuted
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = inputAdUnitId,
                        onValueChange = { inputAdUnitId = it },
                        placeholder = { Text("ca-app-pub-XXXXXXXXXXXXXXXX/YYYYYYYYYY", fontSize = 12.sp, color = ElegantDarkTextMuted) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("input_banner_ad_unit_id"),
                        shape = RoundedCornerShape(12.dp),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = ElegantDarkPrimary,
                            unfocusedBorderColor = ElegantDarkBorder,
                            focusedTextColor = ElegantDarkText,
                            unfocusedTextColor = ElegantDarkText,
                            focusedContainerColor = ElegantDarkSurfaceVariant,
                            unfocusedContainerColor = ElegantDarkSurfaceVariant
                        )
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(
                            onClick = {
                                inputAdUnitId = ""
                                viewModel.updateBannerAdUnitId("")
                            },
                            modifier = Modifier.weight(1f).testTag("btn_reset_ad_id"),
                            shape = RoundedCornerShape(10.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, ElegantDarkBorder)
                        ) {
                            Icon(Icons.Default.RestartAlt, contentDescription = null, modifier = Modifier.size(16.dp), tint = ElegantDarkText)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("রিসেট", fontSize = 12.sp, color = ElegantDarkText)
                        }

                        Button(
                            onClick = {
                                viewModel.updateBannerAdUnitId(inputAdUnitId)
                            },
                            modifier = Modifier.weight(1f).testTag("btn_save_ad_id"),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = ElegantDarkPrimary,
                                contentColor = Color(0xFF381E72)
                            ),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("সেভ করুন", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // Test Mode Toggle Card
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(18.dp))
                    .border(1.dp, ElegantDarkBorder, RoundedCornerShape(18.dp))
                    .testTag("test_mode_card"),
                colors = CardDefaults.cardColors(
                    containerColor = ElegantDarkSurface
                )
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(ElegantDarkPrimary.copy(alpha = 0.15f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Shield,
                                contentDescription = null,
                                tint = ElegantDarkPrimary,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "গুগল টেস্ট অ্যাড মোড",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = ElegantDarkText
                            )
                            Text(
                                text = if (isTestMode) "টেস্ট অ্যাড প্রদর্শিত হচ্ছে (পলিসি সেফ)" else "লাইভ রেভিনিউ অ্যাড চালু",
                                fontSize = 11.sp,
                                color = ElegantDarkTextMuted
                            )
                        }
                    }

                    Switch(
                        checked = isTestMode,
                        onCheckedChange = { viewModel.toggleAdTestMode(it) },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = ElegantDarkPrimary,
                            checkedTrackColor = Color(0xFF381E72),
                            uncheckedThumbColor = Color.Gray,
                            uncheckedTrackColor = ElegantDarkBorder
                        ),
                        modifier = Modifier.testTag("switch_test_mode")
                    )
                }
            }
        }

        // AdMob Monetization Guide
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(18.dp))
                    .border(1.dp, ElegantDarkBorder, RoundedCornerShape(18.dp))
                    .testTag("admob_guide_card"),
                colors = CardDefaults.cardColors(
                    containerColor = ElegantDarkSurfaceVariant.copy(alpha = 0.6f)
                )
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.HelpOutline,
                            contentDescription = null,
                            tint = Color(0xFFFFB300),
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "অ্যাডমব থেকে সর্বোচ্চ টাকা আয়ের টিপস",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = ElegantDarkText
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    val tips = listOf(
                        "১. গুগল প্লে কনসোলে অ্যাপ পাবলিশ করার পর AdMob একাউন্টে অ্যাপ লিংক করে নিন।",
                        "২. ব্যানার অ্যাড সর্বদা ব্যবহারকারীর কন্টেন্ট দেখার সুবিধাজনক স্থানে রাখুন যেন কোনো মিসক্লিক না হয়।",
                        "৩. টিকটক, ফেসবুক ও টেলিগ্রাম গ্রুপ থেকে অ্যাপে ইউজার আনলে ডেইলি ইম্প্রেশন ও আর্নিং বৃদ্ধি পাবে।",
                        "৪. টেস্ট করার সময় সবসময় টেস্ট মোড অন রাখবেন যাতে পলিসি ভায়োলেশন না হয়।"
                    )

                    tips.forEach { tip ->
                        Text(
                            text = tip,
                            fontSize = 12.sp,
                            lineHeight = 18.sp,
                            color = ElegantDarkTextMuted,
                            modifier = Modifier.padding(vertical = 2.dp)
                        )
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

