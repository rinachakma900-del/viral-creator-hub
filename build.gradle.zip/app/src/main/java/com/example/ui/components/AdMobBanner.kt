package com.example.ui.components

import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.ui.theme.ElegantDarkAccentGreen
import com.example.ui.theme.ElegantDarkBorder
import com.example.ui.theme.ElegantDarkSurfaceVariant
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds

@Composable
fun AdMobBannerView(
    adUnitId: String,
    modifier: Modifier = Modifier,
    isTestMode: Boolean = true
) {
    val context = LocalContext.current
    var adLoaded by remember { mutableStateOf(false) }
    var adError by remember { mutableStateOf<String?>(null) }

    val effectiveAdUnitId = if (isTestMode || adUnitId.isBlank() || adUnitId.contains("[")) {
        "ca-app-pub-3940256099942544/6300978111" // Official Google Test Banner Ad Unit ID
    } else {
        adUnitId.trim()
    }

    DisposableEffect(Unit) {
        try {
            MobileAds.initialize(context) {}
        } catch (_: Exception) {}
        onDispose { }
    }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(ElegantDarkSurfaceVariant.copy(alpha = 0.6f))
            .border(
                width = 1.dp,
                color = ElegantDarkBorder,
                shape = RoundedCornerShape(16.dp)
            )
            .padding(vertical = 8.dp, horizontal = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(bottom = 6.dp)
        ) {
            Icon(
                imageVector = if (adLoaded) Icons.Default.CheckCircle else Icons.Default.Info,
                contentDescription = "AdMob Status",
                tint = if (adLoaded) ElegantDarkAccentGreen else MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(14.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = if (isTestMode || adUnitId.isBlank() || adUnitId.contains("[")) {
                    "Google AdMob (টেস্ট মোড এক্টিভ - লাইভ আইডি সেটিংস থেকে যুক্ত করুন)"
                } else {
                    "Google AdMob ব্যানার বিজ্ঞাপন (রেভিনিউ এক্টিভ)"
                },
                fontSize = 11.sp,
                fontWeight = FontWeight.Medium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp)
                .testTag("admob_banner_box"),
            contentAlignment = Alignment.Center
        ) {
            AndroidView(
                modifier = Modifier.fillMaxWidth(),
                factory = { ctx ->
                    val container = FrameLayout(ctx).apply {
                        layoutParams = ViewGroup.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.WRAP_CONTENT
                        )
                    }
                    try {
                        val adView = AdView(ctx).apply {
                            setAdSize(AdSize.BANNER)
                            this.adUnitId = effectiveAdUnitId
                            adListener = object : AdListener() {
                                override fun onAdLoaded() {
                                    super.onAdLoaded()
                                    adLoaded = true
                                    adError = null
                                }

                                override fun onAdFailedToLoad(error: LoadAdError) {
                                    super.onAdFailedToLoad(error)
                                    adLoaded = false
                                    adError = error.message
                                }
                            }
                        }
                        val adRequest = AdRequest.Builder().build()
                        adView.loadAd(adRequest)
                        container.addView(adView)
                    } catch (e: Exception) {
                        adError = e.message
                    }
                    container
                },
                update = { container ->
                    // View update if needed
                }
            )

            if (!adLoaded && adError != null) {
                Text(
                    text = "বিজ্ঞাপন লোড হচ্ছে / টেস্ট মোড স্লট তৈরি সম্পন্ন",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f)
                )
            }
        }
    }
}

