package com.example.ui.screens

import android.content.Context
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.OpenInNew
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CardGiftcard
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.PlayCircleFilled
import androidx.compose.material.icons.filled.RocketLaunch
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.CreatorSocialLink
import com.example.data.model.DiscoveryContentItem
import com.example.data.model.SocialPlatform
import com.example.ui.ViralViewModel
import com.example.ui.components.AdMobBannerView
import com.example.ui.theme.ElegantDarkAccentBlue
import com.example.ui.theme.ElegantDarkAccentFb
import com.example.ui.theme.ElegantDarkAccentGreen
import com.example.ui.theme.ElegantDarkAccentRed
import com.example.ui.theme.ElegantDarkBorder
import com.example.ui.theme.ElegantDarkPrimary
import com.example.ui.theme.ElegantDarkPrimaryContainer
import com.example.ui.theme.ElegantDarkSurface
import com.example.ui.theme.ElegantDarkSurfaceVariant
import com.example.ui.theme.ElegantDarkText
import com.example.ui.theme.ElegantDarkTextMuted
import com.example.ui.theme.ElegantDarkTextSecondary

@Composable
fun HomeScreen(
    viewModel: ViralViewModel,
    bannerAdUnitId: String,
    isTestMode: Boolean,
    onNavigateToAi: () -> Unit,
    onNavigateToEarning: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val wallet by viewModel.walletBalance.collectAsState()
    val discoveryFilter by viewModel.discoveryFilter.collectAsState()
    val milestoneRewards by viewModel.milestoneRewards.collectAsState()

    val filteredDiscovery = if (discoveryFilter == null) {
        viewModel.discoveryFeed
    } else {
        viewModel.discoveryFeed.filter { it.platform == discoveryFilter }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("home_screen_column"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Hero Creator Header Card with Wallet & Stats
        item {
            HeroHeaderCard(
                walletBdt = wallet.availableBdt,
                onNavigateToEarning = onNavigateToEarning,
                onNavigateToAi = onNavigateToAi
            )
        }

        // Live Google AdMob Banner
        item {
            AdMobBannerView(
                adUnitId = bannerAdUnitId,
                isTestMode = isTestMode
            )
        }

        // Creator Milestone Bonus Section
        item {
            val pendingBonus = milestoneRewards.find { it.progressPercent >= 1.0f && !it.isClaimed }
            if (pendingBonus != null) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .border(1.dp, ElegantDarkAccentGreen.copy(alpha = 0.5f), RoundedCornerShape(16.dp))
                        .testTag("milestone_bonus_card"),
                    colors = CardDefaults.cardColors(
                        containerColor = ElegantDarkSurface
                    )
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(44.dp)
                                .clip(CircleShape)
                                .background(ElegantDarkAccentGreen.copy(alpha = 0.15f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.CardGiftcard,
                                contentDescription = null,
                                tint = ElegantDarkAccentGreen,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "ক্রিয়েটর মাইলস্টোন রিওয়ার্ড প্রস্তুত! 🎉",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = ElegantDarkAccentGreen
                            )
                            Text(
                                text = "${pendingBonus.title} (৳${pendingBonus.rewardBdt.toInt()} বোনাস)",
                                fontSize = 12.sp,
                                color = ElegantDarkText
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = { viewModel.claimMilestoneReward(pendingBonus.id) },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = ElegantDarkAccentGreen,
                                contentColor = Color(0xFF00381B)
                            ),
                            shape = RoundedCornerShape(10.dp),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                            modifier = Modifier.testTag("btn_claim_milestone")
                        ) {
                            Text("ক্লেইম", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // Quick Creator Studio Actions
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                QuickActionPill(
                    icon = Icons.Default.AutoAwesome,
                    title = "এআই স্ক্রিপ্ট জেনারেটর",
                    subtitle = "হুক ও ক্যাপশন",
                    accentColor = ElegantDarkPrimary,
                    modifier = Modifier.weight(1f),
                    onClick = onNavigateToAi
                )
                QuickActionPill(
                    icon = Icons.Default.AccountBalanceWallet,
                    title = "আয় ও ক্যাশআউট",
                    subtitle = "বিকাশ / নগদ / ব্যাংক",
                    accentColor = ElegantDarkAccentGreen,
                    modifier = Modifier.weight(1f),
                    onClick = onNavigateToEarning
                )
            }
        }

        // Cross-Platform Content Discovery Header
        item {
            Column(modifier = Modifier.padding(top = 4.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Explore,
                            contentDescription = null,
                            tint = ElegantDarkPrimary,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "সোশ্যাল মিডিয়া ট্রেন্ডিং ডিসকভারি",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = ElegantDarkText
                        )
                    }
                }
                Text(
                    text = "টিকটক, ইউটিউব, ফেসবুক ও টেলিগ্রামের ভাইরাল কন্টেন্ট এক্সপ্লোর ও রি-মিক্স করুন",
                    fontSize = 12.sp,
                    color = ElegantDarkTextMuted,
                    modifier = Modifier.padding(top = 2.dp)
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Discovery Platform Filter Chips
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    item {
                        FilterChip(
                            selected = discoveryFilter == null,
                            onClick = { viewModel.setDiscoveryFilter(null) },
                            label = { Text("সব প্ল্যাটফর্ম", fontSize = 12.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = ElegantDarkPrimary,
                                selectedLabelColor = Color(0xFF381E72),
                                containerColor = ElegantDarkSurface,
                                labelColor = ElegantDarkTextMuted
                            )
                        )
                    }
                    items(SocialPlatform.entries.toTypedArray()) { platform ->
                        FilterChip(
                            selected = discoveryFilter == platform,
                            onClick = { viewModel.setDiscoveryFilter(platform) },
                            label = { Text(platform.displayName, fontSize = 12.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = Color(platform.colorHex).copy(alpha = 0.25f),
                                selectedLabelColor = Color(platform.colorHex),
                                containerColor = ElegantDarkSurface,
                                labelColor = ElegantDarkTextMuted
                            )
                        )
                    }
                }
            }
        }

        // Discovery Items List
        items(filteredDiscovery) { item ->
            DiscoveryCard(
                item = item,
                onOpenUrl = { viewModel.openUrl(context, item.targetUrl) },
                onShare = {
                    viewModel.shareDirectToPlatform(
                        context = context,
                        platform = item.platform,
                        caption = "${item.title}\n${item.sampleHook}",
                        hashtags = item.tags.joinToString(" "),
                        url = item.targetUrl
                    )
                },
                onRemixWithAi = {
                    viewModel.generateContentWithAi(
                        topic = item.title,
                        platformName = item.platform.displayName,
                        formatType = "Short Video Script"
                    )
                    onNavigateToAi()
                }
            )
        }

        // Official Social Links & Channels Header
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.MusicNote,
                    contentDescription = null,
                    tint = ElegantDarkPrimary,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "অফিসিয়াল ক্রিয়েটর চ্যানেল ও প্রোফাইল",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = ElegantDarkText
                )
            }
        }

        // Official Social Channels List
        items(viewModel.socialLinks) { link ->
            SocialLinkCard(
                link = link,
                onOpen = { viewModel.openUrl(context, link.url) },
                onCopy = { viewModel.copyToClipboard(context, link.platformName, link.url) },
                onShare = {
                    viewModel.shareText(
                        context,
                        link.title,
                        "${link.title}\n\n${link.description}\n\nলিংক: ${link.url}"
                    )
                }
            )
        }

        // Bottom Banner Ad
        item {
            Spacer(modifier = Modifier.height(8.dp))
            AdMobBannerView(
                adUnitId = bannerAdUnitId,
                isTestMode = isTestMode
            )
        }
    }
}

@Composable
fun HeroHeaderCard(
    walletBdt: Double,
    onNavigateToEarning: () -> Unit,
    onNavigateToAi: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(22.dp))
            .border(1.dp, ElegantDarkBorder, RoundedCornerShape(22.dp))
            .testTag("hero_header_card"),
        colors = CardDefaults.cardColors(
            containerColor = ElegantDarkSurface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Column(
            modifier = Modifier.padding(18.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Profile Avatar with Gradient Ring
                Box(
                    modifier = Modifier
                        .size(68.dp)
                        .clip(CircleShape)
                        .background(
                            Brush.sweepGradient(
                                listOf(
                                    Color(0xFFFF0050),
                                    Color(0xFFFF0000),
                                    Color(0xFF2AABEE),
                                    Color(0xFF80E1A7),
                                    Color(0xFFFF0050)
                                )
                            )
                        )
                        .padding(2.5.dp)
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.ic_creator_avatar),
                        contentDescription = "Chakma Creator Avatar",
                        modifier = Modifier
                            .fillMaxSize()
                            .clip(CircleShape),
                        contentScale = ContentScale.Crop
                    )
                }

                Spacer(modifier = Modifier.width(14.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "Chakma Music Video",
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold,
                            color = ElegantDarkText
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Icon(
                            imageVector = Icons.Default.Star,
                            contentDescription = "Verified",
                            tint = Color(0xFFFFB300),
                            modifier = Modifier.size(16.dp)
                        )
                    }

                    Text(
                        text = "ভাইরাল ক্রিয়েটর ও আর্নিং হাব ২০২৬",
                        fontSize = 12.sp,
                        color = ElegantDarkTextMuted
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    Surface(
                        color = ElegantDarkAccentGreen.copy(alpha = 0.15f),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.clickable { onNavigateToEarning() }
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.MonetizationOn,
                                contentDescription = null,
                                tint = ElegantDarkAccentGreen,
                                modifier = Modifier.size(13.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "ব্যালেন্স: ৳${walletBdt.toInt()} (উইথড্র রেডি)",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = ElegantDarkAccentGreen
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))
            HorizontalDivider(color = ElegantDarkBorder, thickness = 1.dp)
            Spacer(modifier = Modifier.height(14.dp))

            // Quick Stats Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                StatBadge(label = "মোট রিচ", value = "১.২M+", icon = Icons.Default.TrendingUp, color = Color(0xFFFF0050))
                StatBadge(label = "ইউটিউব সাবস", value = "৩৫০K+", icon = Icons.Default.MusicNote, color = Color(0xFFFF0000))
                StatBadge(label = "টেলিগ্রাম পাওয়ার", value = "৯৮%", icon = Icons.Default.RocketLaunch, color = Color(0xFF2AABEE))
                StatBadge(label = "পজিটিভ ইমপ্যাক্ট", value = "১০০%", icon = Icons.Default.Favorite, color = ElegantDarkAccentGreen)
            }
        }
    }
}

@Composable
fun QuickActionPill(
    icon: ImageVector,
    title: String,
    subtitle: String,
    accentColor: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Card(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .border(1.dp, ElegantDarkBorder, RoundedCornerShape(16.dp))
            .clickable { onClick() },
        colors = CardDefaults.cardColors(containerColor = ElegantDarkSurface)
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(accentColor.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, contentDescription = null, tint = accentColor, modifier = Modifier.size(20.dp))
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column {
                Text(text = title, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = ElegantDarkText)
                Text(text = subtitle, fontSize = 10.sp, color = ElegantDarkTextMuted)
            }
        }
    }
}

@Composable
fun DiscoveryCard(
    item: DiscoveryContentItem,
    onOpenUrl: () -> Unit,
    onShare: () -> Unit,
    onRemixWithAi: () -> Unit
) {
    val platformColor = Color(item.platform.colorHex)

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .border(1.dp, ElegantDarkBorder, RoundedCornerShape(18.dp))
            .testTag("discovery_card_${item.id}"),
        colors = CardDefaults.cardColors(containerColor = ElegantDarkSurface)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Platform Badge & Category Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    color = platformColor.copy(alpha = 0.15f),
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = item.platform.displayName,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = platformColor
                        )
                    }
                }

                Surface(
                    color = ElegantDarkSurfaceVariant,
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Text(
                        text = item.category,
                        fontSize = 10.sp,
                        color = ElegantDarkTextMuted,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = item.title,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = ElegantDarkText,
                lineHeight = 20.sp
            )

            Spacer(modifier = Modifier.height(6.dp))

            // Sample Hook Box
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(ElegantDarkSurfaceVariant)
                    .padding(10.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(text = "🔥 হুক: ", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFFFFB300))
                    Text(text = item.sampleHook, fontSize = 11.sp, color = ElegantDarkTextSecondary)
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Metrics row
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Visibility, contentDescription = null, tint = ElegantDarkTextMuted, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(text = item.viewsCount, fontSize = 11.sp, color = ElegantDarkTextMuted)
                }

                Spacer(modifier = Modifier.width(14.dp))

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Favorite, contentDescription = null, tint = Color(0xFFFF0050), modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(text = item.likesCount, fontSize = 11.sp, color = ElegantDarkTextMuted)
                }

                Spacer(modifier = Modifier.weight(1f))

                Text(
                    text = "ভাইরালিটি: ${item.viralityScore}%",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = ElegantDarkAccentGreen
                )
            }

            Spacer(modifier = Modifier.height(12.dp))
            HorizontalDivider(color = ElegantDarkBorder, thickness = 1.dp)
            Spacer(modifier = Modifier.height(12.dp))

            // Action Buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = onOpenUrl,
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(10.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, platformColor.copy(alpha = 0.5f))
                ) {
                    Icon(Icons.Default.PlayArrow, contentDescription = null, tint = platformColor, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("দেখুন", fontSize = 12.sp, color = platformColor)
                }

                Button(
                    onClick = onRemixWithAi,
                    modifier = Modifier.weight(1.3f),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = ElegantDarkPrimary,
                        contentColor = Color(0xFF381E72)
                    ),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Icon(Icons.Default.AutoAwesome, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("এআই রি-মিক্স", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }

                IconButton(
                    onClick = onShare,
                    modifier = Modifier
                        .size(40.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(ElegantDarkSurfaceVariant)
                ) {
                    Icon(Icons.Default.Share, contentDescription = "Share", tint = ElegantDarkText, modifier = Modifier.size(18.dp))
                }
            }
        }
    }
}

@Composable
fun SocialLinkCard(
    link: CreatorSocialLink,
    onOpen: () -> Unit,
    onCopy: () -> Unit,
    onShare: () -> Unit
) {
    val platformColor = when (link.id) {
        "tiktok" -> Color(0xFFFF0050)
        "youtube" -> Color(0xFFFF0000)
        "facebook" -> Color(0xFF1877F2)
        "telegram" -> Color(0xFF2AABEE)
        else -> Color(link.primaryColorHex)
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .border(1.dp, ElegantDarkBorder, RoundedCornerShape(18.dp))
            .testTag("card_${link.id}"),
        colors = CardDefaults.cardColors(
            containerColor = ElegantDarkSurface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(46.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(platformColor.copy(alpha = 0.15f))
                        .border(1.dp, platformColor.copy(alpha = 0.3f), RoundedCornerShape(12.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = when (link.id) {
                            "tiktok" -> Icons.Default.PlayCircleFilled
                            "youtube" -> Icons.Default.MusicNote
                            "facebook" -> Icons.Default.Share
                            else -> Icons.Default.RocketLaunch
                        },
                        contentDescription = link.platformName,
                        tint = platformColor,
                        modifier = Modifier.size(24.dp)
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = link.platformName,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = ElegantDarkText
                        )
                        Surface(
                            color = platformColor.copy(alpha = 0.15f),
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(
                                text = link.badgeText,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = platformColor,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                    Text(
                        text = link.handle,
                        fontSize = 11.sp,
                        color = ElegantDarkTextMuted
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = link.title,
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold,
                color = ElegantDarkTextSecondary
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = link.description,
                fontSize = 11.sp,
                color = ElegantDarkTextMuted,
                lineHeight = 16.sp
            )

            Spacer(modifier = Modifier.height(14.dp))

            // Action Buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Button(
                    onClick = onOpen,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("btn_open_${link.id}"),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = platformColor,
                        contentColor = Color.White
                    ),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.OpenInNew,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "ওপেন করুন",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                OutlinedButton(
                    onClick = onCopy,
                    modifier = Modifier.testTag("btn_copy_${link.id}"),
                    shape = RoundedCornerShape(10.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, ElegantDarkBorder)
                ) {
                    Icon(
                        imageVector = Icons.Default.ContentCopy,
                        contentDescription = "Copy",
                        modifier = Modifier.size(16.dp),
                        tint = ElegantDarkText
                    )
                }

                OutlinedButton(
                    onClick = onShare,
                    modifier = Modifier.testTag("btn_share_${link.id}"),
                    shape = RoundedCornerShape(10.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, ElegantDarkBorder)
                ) {
                    Icon(
                        imageVector = Icons.Default.Share,
                        contentDescription = "Share",
                        modifier = Modifier.size(16.dp),
                        tint = ElegantDarkText
                    )
                }
            }
        }
    }
}

@Composable
fun StatBadge(
    label: String,
    value: String,
    icon: ImageVector,
    color: Color
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(12.dp))
            Spacer(modifier = Modifier.width(2.dp))
            Text(
                text = value,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = ElegantDarkText
            )
        }
        Text(
            text = label,
            fontSize = 10.sp,
            color = ElegantDarkTextMuted
        )
    }
}
