package com.example.ui

import android.app.Application
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.BuildConfig
import com.example.data.model.AiChatMessage
import com.example.data.model.CreatorMilestoneReward
import com.example.data.model.CreatorSocialLink
import com.example.data.model.DiscoveryContentItem
import com.example.data.model.EarningSource
import com.example.data.model.GeneratedAiContent
import com.example.data.model.PremiumSubscriptionTier
import com.example.data.model.SocialPlatform
import com.example.data.model.SponsoredCampaign
import com.example.data.model.TrendingTopicSuggestion
import com.example.data.model.ViralScriptTemplate
import com.example.data.model.ViralTip
import com.example.data.model.WalletBalance
import com.example.data.model.WithdrawalMethod
import com.example.data.model.WithdrawalStatus
import com.example.data.model.WithdrawalTransaction
import com.example.data.network.GeminiClient
import com.example.data.network.GeminiContent
import com.example.data.network.GeminiPart
import com.example.data.network.GeminiRequest
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

class ViralViewModel(application: Application) : AndroidViewModel(application) {

    private val sharedPrefs = application.getSharedPreferences("viral_hub_prefs", Context.MODE_PRIVATE)
    private val usdToBdtRate = 122.5

    // ==========================================
    // 1. Social Creator Channels
    // ==========================================
    val socialLinks = listOf(
        CreatorSocialLink(
            id = "tiktok",
            title = "টিকটক ভাইরাল প্রোফাইল ও পোস্ট",
            platformName = "TikTok Lite",
            url = "https://vm.tiktok.com/ZSVw2r989/",
            handle = "@vm.tiktok.com/ZSVw2r989",
            description = "চাকমা মিউজিক ও ভাইরাল শর্টস ভিডিও দেখতে এবং লাইক/শেয়ার করতে ফলো করুন",
            badgeText = "ভাইরাল পোস্ট 🔥",
            primaryColorHex = 0xFFFF0050
        ),
        CreatorSocialLink(
            id = "youtube",
            title = "চাকমা মিউজিক ভিডিও চ্যানেল",
            platformName = "YouTube",
            url = "https://www.youtube.com/@Chakma-music-Video",
            handle = "@Chakma-music-Video",
            description = "অফিসিয়াল মিউজিক ভিডিও, নতুন গান ও ভাইরাল কন্টেন্ট সাবস্ক্রাইব করুন",
            badgeText = "অফিসিয়াল ইউটিউব 🎵",
            primaryColorHex = 0xFFFF0000
        ),
        CreatorSocialLink(
            id = "facebook",
            title = "অফিসিয়াল ফেসবুক পেজ / প্রোফাইল",
            platformName = "Facebook",
            url = "https://www.facebook.com/profile.php?id=61593411089547",
            handle = "ID: 61593411089547",
            description = "ফেসবুক রিলস, আপডেট, লাইভ মিউজিক ও ক্রিয়েটর কমিউনিটিতে যুক্ত হোন",
            badgeText = "কমিউনিটি হাব 👥",
            primaryColorHex = 0xFF1877F2
        ),
        CreatorSocialLink(
            id = "telegram",
            title = "টেলিগ্রাম আর্নিং ও বুস্ট চ্যানেল",
            platformName = "Telegram Boost",
            url = "https://t.me/boost/JuwelChakma989",
            handle = "@JuwelChakma989",
            description = "ভিডিও বুস্ট করুন, ভাইরাল স্ট্র্যাটেজি এবং আর্নিং আপডেট পেতে জয়েন করুন",
            badgeText = "বুস্ট চ্যানেল 🚀",
            primaryColorHex = 0xFF2AABEE
        )
    )

    // ==========================================
    // 2. AdMob Settings
    // ==========================================
    private val _bannerAdUnitId = MutableStateFlow(
        sharedPrefs.getString("banner_ad_unit_id", "") ?: ""
    )
    val bannerAdUnitId: StateFlow<String> = _bannerAdUnitId.asStateFlow()

    private val _isAdTestMode = MutableStateFlow(
        sharedPrefs.getBoolean("ad_test_mode", true)
    )
    val isAdTestMode: StateFlow<Boolean> = _isAdTestMode.asStateFlow()

    // ==========================================
    // 3. Creator Monetization & Wallet State
    // ==========================================
    private val _walletBalance = MutableStateFlow(
        WalletBalance(
            availableBdt = sharedPrefs.getFloat("wallet_avail_bdt", 18500.0f).toDouble(),
            pendingBdt = sharedPrefs.getFloat("wallet_pending_bdt", 6200.0f).toDouble(),
            lifetimeBdt = sharedPrefs.getFloat("wallet_lifetime_bdt", 84500.0f).toDouble(),
            availableUsd = sharedPrefs.getFloat("wallet_avail_bdt", 18500.0f) / usdToBdtRate,
            pendingUsd = sharedPrefs.getFloat("wallet_pending_bdt", 6200.0f) / usdToBdtRate,
            lifetimeUsd = sharedPrefs.getFloat("wallet_lifetime_bdt", 84500.0f) / usdToBdtRate
        )
    )
    val walletBalance: StateFlow<WalletBalance> = _walletBalance.asStateFlow()

    val earningSources = listOf(
        EarningSource("pool", "পপুলার কন্টেন্ট ভিউ রিওয়ার্ড পুল", "১০০K+ ভিউয়ারশিপ ও ভাইরাল বোনাস", 38200.0, 0.45f, 0xFF80E1A7),
        EarningSource("sponsors", "স্পন্সরড ক্যাম্পেইন ও ব্র্যান্ড ডিল", "মিউজিক প্রোমোশন ও ব্র্যান্ড স্পনসর", 24500.0, 0.29f, 0xFFD0BCFF),
        EarningSource("subs", "ফ্যান সাবস্ক্রিপশন ও ভিআইপি মেম্বারশিপ", "এক্সক্লুসিভ কন্টেন্ট ও অডিও ট্র্যাক পাস", 14800.0, 0.18f, 0xFFFFB300),
        EarningSource("admob", "ইন-অ্যাপ অ্যাডমব ও রেভিনিউ শেয়ার", "ব্যানার ও অ্যাপ ইন্টিগ্রেশন ইনকাম", 7000.0, 0.08f, 0xFF64B5F6)
    )

    val withdrawalMethods = listOf(
        WithdrawalMethod("bkash", "bKash (বিকাশ)", "০% চার্জ", 500.0, "ইনস্ট্যান্ট - ২ ঘণ্টা", "01XXXXXXXXX", 0xFFE2136E),
        WithdrawalMethod("nagad", "Nagad (নগদ)", "০% চার্জ", 500.0, "ইনস্ট্যান্ট - ২ ঘণ্টা", "01XXXXXXXXX", 0xFFF7941D),
        WithdrawalMethod("rocket", "Rocket (রকেট)", "১% চার্জ", 500.0, "১২ ঘণ্টা", "01XXXXXXXXX", 0xFF8C3494),
        WithdrawalMethod("bank", "ব্যাংক ট্রান্সফার (Bank Wire)", "ফ্রি", 2000.0, "১-২ কার্যদিবস", "Bank Name, A/C No, Branch", 0xFF4CAF50),
        WithdrawalMethod("paypal", "PayPal (USD)", "২% ফি", 1200.0, "২৪ ঘণ্টা", "name@email.com", 0xFF003087),
        WithdrawalMethod("crypto", "USDT (TRC-20 / Binance)", "নেটওয়ার্ক ফি $1", 1200.0, "৩০ মিনিট", "TRC20 Wallet Address", 0xFF26A17B)
    )

    private val _withdrawalHistory = MutableStateFlow<List<WithdrawalTransaction>>(
        listOf(
            WithdrawalTransaction("tx_01", "০১ সেপ্টেম্বর ২০২৬", "bKash (বিকাশ)", "017***9890", 5000.0, WithdrawalStatus.COMPLETED, "TRX9981A42"),
            WithdrawalTransaction("tx_02", "২৮ আগস্ট ২০২৬", "Nagad (নগদ)", "018***4521", 8500.0, WithdrawalStatus.COMPLETED, "NGD8823K19"),
            WithdrawalTransaction("tx_03", "২১ আগস্ট ২০২৬", "ব্যাংক ট্রান্সফার", "BRAC Bank (Ac: 401...)", 15000.0, WithdrawalStatus.COMPLETED, "FT26233091"),
            WithdrawalTransaction("tx_04", "আজকে", "bKash (বিকাশ)", "017***9890", 2500.0, WithdrawalStatus.PROCESSING, "TRX9988C77")
        )
    )
    val withdrawalHistory: StateFlow<List<WithdrawalTransaction>> = _withdrawalHistory.asStateFlow()

    private val _sponsoredCampaigns = MutableStateFlow<List<SponsoredCampaign>>(
        listOf(
            SponsoredCampaign(
                id = "camp_01",
                brandName = "Chakma Folk Heritage Records",
                title = "নতুন চাকমা মিউজিক ভিডিও রিলস ড্যান্স চ্যালেঞ্জ",
                payoutBdt = 12500.0,
                category = "মিউজিক প্রোমোশন",
                spotsLeft = 4,
                deadline = "১৫ সেপ্টেম্বর ২০২৬",
                requirements = "অফিসিয়াল গান দিয়ে একটি ১৫-৩০ সেকেন্ডের রিল তৈরি করুন এবং ক্যাপশনে #ChakmaMusicVideo ট্যাগ করুন।",
                isApplied = false
            ),
            SponsoredCampaign(
                id = "camp_02",
                brandName = "Green Hills Eco Tourism",
                title = "পাহাড়ি সংস্কৃতি ও ভালো কাজের ডকুমেন্টারি শর্ট",
                payoutBdt = 18000.0,
                category = "পজিটিভ সোশ্যাল ইনফ্লুয়েন্স",
                spotsLeft = 2,
                deadline = "২০ সেপ্টেম্বর ২০২৬",
                requirements = "পাহাড়ের প্রাকৃতিক সৌন্দর্য বা গ্রামীণ সৎ উদ্যোগ নিয়ে একটি পজিটিভ শিক্ষণীয় ভিডিও আপলোড করুন।",
                isApplied = true
            ),
            SponsoredCampaign(
                id = "camp_03",
                brandName = "Digital Creator Pro Tools",
                title = "এআই ভিডিও মেকিং ও আর্নিং অ্যাপ রিভিউ",
                payoutBdt = 9500.0,
                category = "টেক ও এডুকেশন",
                spotsLeft = 7,
                deadline = "২৫ সেপ্টেম্বর ২০২৬",
                requirements = "অ্যাপের ভাইরাল এআই ফিচার এবং টিকটক/ইউটিউব শেয়ারিং নিয়ে একটি আকর্ষণীয় স্ক্রিন রেকর্ড ভিডিও।",
                isApplied = false
            )
        )
    )
    val sponsoredCampaigns: StateFlow<List<SponsoredCampaign>> = _sponsoredCampaigns.asStateFlow()

    private val _premiumTiers = MutableStateFlow<List<PremiumSubscriptionTier>>(
        listOf(
            PremiumSubscriptionTier(
                id = "tier_fan",
                title = "সাপোর্টার ব্যাজ (Supporter Pass)",
                priceBdt = 199.0,
                billingCycle = "প্রতি মাস",
                activeSubscribers = 42,
                perks = listOf("লাইভ চ্যাট ও কমেন্টে স্পেশাল গোল্ডেন স্টার ব্যাজ", "নতুন গান রিলিজের ২৪ ঘণ্টা আগে আর্লি অ্যাক্সেস", "এক্সক্লুসিভ টেলিগ্রাম ভিআইপি গ্রুপ লিঙ্ক")
            ),
            PremiumSubscriptionTier(
                id = "tier_pro",
                title = "ভিআইপি প্যাট্রন (VIP Patron)",
                priceBdt = 499.0,
                billingCycle = "প্রতি মাস",
                activeSubscribers = 18,
                perks = listOf("ফুল হাই-রেজোলিউশন অডিও ও লিরিক ফাইল ডাউনলোড", "মাসিক ক্রিয়েটর লাইভ সেশন ও প্রশ্নোত্তর", "সব সাপোর্টার সুবিধা অন্তর্ভুক্ত")
            ),
            PremiumSubscriptionTier(
                id = "tier_producer",
                title = "এক্সিকিউটিভ প্রডিউসার (Producer Pass)",
                priceBdt = 1499.0,
                billingCycle = "প্রতি মাস",
                activeSubscribers = 5,
                perks = listOf("অফিসিয়াল মিউজিক ভিডিওর ডেসক্রিপশনে স্পেশাল থ্যাঙ্কস ক্রেডিট", "১-অন-১ কন্টেন্ট ক্রিয়েশন ও ভাইরাল পরামর্শ", "সব ভিআইপি সুবিধা অন্তর্ভুক্ত")
            )
        )
    )
    val premiumTiers: StateFlow<List<PremiumSubscriptionTier>> = _premiumTiers.asStateFlow()

    private val _milestoneRewards = MutableStateFlow<List<CreatorMilestoneReward>>(
        listOf(
            CreatorMilestoneReward("m1", "১০,০০০ মোট ভিডিও ভিউ পূর্ণ", "10,000 Views", 1000.0, 1.0f, true),
            CreatorMilestoneReward("m2", "৫০,০০০ মোট ভিডিও ভিউ পূর্ণ", "50,000 Views", 3500.0, 1.0f, false),
            CreatorMilestoneReward("m3", "১০০,০০০ মোট ভিডিও ভিউ পূর্ণ", "100,000 Views", 8000.0, 0.72f, false),
            CreatorMilestoneReward("m4", "৫০০,০০০ মেগা ভাইরাল মাইলস্টোন", "500,000 Views", 35000.0, 0.35f, false)
        )
    )
    val milestoneRewards: StateFlow<List<CreatorMilestoneReward>> = _milestoneRewards.asStateFlow()

    // ==========================================
    // 4. AI Content Generator & Chat State
    // ==========================================
    val trendingTopicSuggestions = listOf(
        TrendingTopicSuggestion(
            id = "trend_1",
            title = "চাকমা রোমান্টিক মিউজিক ভিডিও ও ড্রোন শট লিরিক্স",
            category = "মিউজিক ও কালচার",
            viralPotential = "৯৯% ভাইরাল রেটিং",
            whyItWorks = "শ্রোতারা খাঁটি পাহাড়ি সুর ও মনমুগ্ধকর প্রাকৃতিক লোকেশন দেখতে পছন্দ করে।",
            positiveAngle = "নিজস্ব লোকসংস্কৃতি ও ভাষাকে বিশ্বমঞ্চে গর্বের সাথে তুলে ধরা।"
        ),
        TrendingTopicSuggestion(
            id = "trend_2",
            title = "অসহায় মানুষের পাশে দাঁড়ানোর সৎ মানবিক গল্প",
            category = "ভালো কাজ ও অনুপ্রেরণা",
            viralPotential = "৯৭% শেয়ার রেট",
            whyItWorks = "ইমোশনাল কানেকশন তৈরি করে এবং দর্শকরা স্বেচ্ছায় ভিডিও শেয়ার করে আলো ছড়ায়।",
            positiveAngle = "সমাজকল্যাণ, দয়া ও অন্যকে ভালো কাজে উদ্বুদ্ধ করা।"
        ),
        TrendingTopicSuggestion(
            id = "trend_3",
            title = "অনলাইন ও সোশ্যাল মিডিয়া থেকে সঠিক নিয়মে আয়",
            category = "শিক্ষা ও ক্যারিয়ার",
            viralPotential = "৯৫% সেভ রেট",
            whyItWorks = "তরুণ প্রজন্মের মাঝে জেনুইন ইনকাম গাইডলাইনের প্রচুর চাহিদা রয়েছে।",
            positiveAngle = "সততা, ধৈর্য ও সঠিক ফ্রিল্যান্সিং স্কিল অর্জনের নির্দেশনা দেওয়া।"
        ),
        TrendingTopicSuggestion(
            id = "trend_4",
            title = "পাহাড়ি পাহাড়ি ফল ও অর্গানিক খাবারের রূপকথা",
            category = "লাইফস্টাইল ও ঐতিহ্য",
            viralPotential = "৯৩% এনগেজমেন্ট",
            whyItWorks = "স্বাভাবিক গ্রামীণ জীবনধারা ও স্বাস্থ্যকর খাদ্যাভ্যাস দেখতে মানুষ ভালোবাসে।",
            positiveAngle = "প্রকৃতি প্রেম ও সুস্থ জীবনযাপনের ইতিবাচক বার্তা।"
        )
    )

    private val _generatedContent = MutableStateFlow<GeneratedAiContent?>(null)
    val generatedContent: StateFlow<GeneratedAiContent?> = _generatedContent.asStateFlow()

    private val _isGeneratingContent = MutableStateFlow(false)
    val isGeneratingContent: StateFlow<Boolean> = _isGeneratingContent.asStateFlow()

    // AI Chat State
    private val _chatMessages = MutableStateFlow<List<AiChatMessage>>(
        listOf(
            AiChatMessage(
                id = UUID.randomUUID().toString(),
                text = "নমস্কার ও স্বাগতম! আমি আপনার ক্রিয়েটর এআই সহকারী ও কন্টেন্ট জেনারেটর。\n\nআমি আপনাকে সাহায্য করতে পারি:\n• চাকমা মিউজিক ভিডিও, গান ও রিলসের জন্য ৩ সেকেন্ডের পাওয়ারফুল হুক\n• সম্পূর্ণ শর্ট ভিডিও স্ক্রিপ্ট (ভিজ্যুয়াল নির্দেশনা, অডিও কিউ ও কল-টু-অ্যাকশন সহ)\n• টিকটক, ইউটিউব, ফেসবুক ও টেলিগ্রামের জন্য আকর্ষনীয় পজিটিভ ক্যাপশন ও হ্যাশট্যাগ\n• ইন-অ্যাপ মনিটাইজেশন, স্পনসরশিপ ও উইথড্রয়াল সংক্রান্ত যেকোনো পরামর্শ。\n\nযেকোনো বিষয়ে জানতে নিচে লিখুন বা টপিক জেনারেটর ব্যবহার করুন!",
                isUser = false
            )
        )
    )
    val chatMessages: StateFlow<List<AiChatMessage>> = _chatMessages.asStateFlow()

    private val _isAiLoading = MutableStateFlow(false)
    val isAiLoading: StateFlow<Boolean> = _isAiLoading.asStateFlow()

    // ==========================================
    // 5. Cross-Platform Content Discovery Feed
    // ==========================================
    val discoveryFeed = listOf(
        DiscoveryContentItem(
            id = "disc_yt_1",
            platform = SocialPlatform.YOUTUBE,
            title = "Official Chakma Music Video 2026 - মন জুড়ানো নতুন পাহাড়ি সুর",
            creatorName = "Chakma Music Video",
            creatorHandle = "@Chakma-music-Video",
            viewsCount = "৩৫০K ভিউ",
            likesCount = "৪২K লাইক",
            viralityScore = 98,
            targetUrl = "https://www.youtube.com/@Chakma-music-Video",
            category = "মিউজিক ভিডিও",
            sampleHook = "গানটির এই অংশ শুনলে আপনার পাহাড়ে যেতে ইচ্ছে করবেই! 🎵🌲",
            tags = listOf("#ChakmaSong", "#ChakmaMusicVideo", "#TrendingMusic", "#PahariSong")
        ),
        DiscoveryContentItem(
            id = "disc_tt_1",
            platform = SocialPlatform.TIKTOK,
            title = "টিকটক ট্রেন্ডিং রিলস ক্লিপ - পাহাড়ি নাচের সেরা স্টেপস",
            creatorName = "Viral TikTok Star",
            creatorHandle = "@vm.tiktok.com/ZSVw2r989",
            viewsCount = "৬২০K ভিউ",
            likesCount = "৮৮K লাইক",
            viralityScore = 99,
            targetUrl = "https://vm.tiktok.com/ZSVw2r989/",
            category = "টিকটক শর্টস",
            sampleHook = "কেউ বলবে না কিভাবে এই নাচের স্টেপ এত পারফেক্ট হলো...",
            tags = listOf("#TikTokViral", "#DanceChallenge", "#ChakmaVibes", "#ViralShorts")
        ),
        DiscoveryContentItem(
            id = "disc_fb_1",
            platform = SocialPlatform.FACEBOOK,
            title = "মানবতার সেবায় একদল তরুণ - ভালো কাজের অনুপ্রেরণা",
            creatorName = "Community Page",
            creatorHandle = "ID: 61593411089547",
            viewsCount = "১৮০K ভিউ",
            likesCount = "২৫K লাইক",
            viralityScore = 94,
            targetUrl = "https://www.facebook.com/profile.php?id=61593411089547",
            category = "ভালো কাজ ও সমাজকল্যাণ",
            sampleHook = "ছোট্ট একটি দয়া কারোর পুরো জীবন বদলে দিতে পারে...",
            tags = listOf("#GoodDeeds", "#HumanityFirst", "#PositiveContent", "#ReelsViral")
        ),
        DiscoveryContentItem(
            id = "disc_tg_1",
            platform = SocialPlatform.TELEGRAM,
            title = "টেলিগ্রাম বুস্ট ও কন্টেন্ট ক্রিয়েটর আর্নিং সিক্রেট টিপস",
            creatorName = "Juwel Chakma",
            creatorHandle = "@JuwelChakma989",
            viewsCount = "৯৫K রিড",
            likesCount = "১২K রিঅ্যাক্ট",
            viralityScore = 91,
            targetUrl = "https://t.me/boost/JuwelChakma989",
            category = "আর্নিং স্ট্র্যাটেজি",
            sampleHook = "ভিডিও আপলোডের প্রথম ১ ঘণ্টার গোল্ডেন ফর্মুলা জানুন!",
            tags = listOf("#TelegramBoost", "#CreatorMonetization", "#OnlineIncome", "#GrowChannel")
        )
    )

    private val _discoveryFilter = MutableStateFlow<SocialPlatform?>(null)
    val discoveryFilter: StateFlow<SocialPlatform?> = _discoveryFilter.asStateFlow()

    // ==========================================
    // 6. Earning Calculator & Checklist
    // ==========================================
    private val _calculatorViews = MutableStateFlow(50000L)
    val calculatorViews: StateFlow<Long> = _calculatorViews.asStateFlow()

    private val _calculatorPlatform = MutableStateFlow("YouTube (শর্টস/ভিডিও)")
    val calculatorPlatform: StateFlow<String> = _calculatorPlatform.asStateFlow()

    private val _calculatorCpm = MutableStateFlow(1.5f)
    val calculatorCpm: StateFlow<Float> = _calculatorCpm.asStateFlow()

    private val _checklistState = MutableStateFlow(
        mapOf(
            "hook" to true,
            "trending_sound" to true,
            "caption_cta" to false,
            "high_contrast_thumb" to false,
            "telegram_share" to false,
            "good_message" to true
        )
    )
    val checklistState: StateFlow<Map<String, Boolean>> = _checklistState.asStateFlow()

    val scriptTemplates = listOf(
        ViralScriptTemplate(
            id = "music_video_hook",
            title = "চাকমা মিউজিক ভিডিও ভাইরাল হুক (Reels / TikTok)",
            type = "মিউজিক প্রোমোশন",
            hook = "এই চাকমা গানের লিরিকটা শুনলে আপনিও ভালোবাসায় হারিয়ে যাবেন... 🎶✨",
            body = "ভিডিও ক্লিপে গানের সেরা ক্লাইম্যাক্স অংশ ৫ সেকেন্ড প্লে হবে। সাথে অন-স্ক্রিন লিরিক টেক্সট এবং সুন্দর পাহাড় ও পাহাড়ী সংস্কৃতির ড্রোন শট।",
            cta = "সম্পূর্ণ অফিশিয়াল মিউজিক ভিডিও দেখতে উপরের ইউটিউব লিংকে এখনই ক্লিক করুন এবং বন্ধুদের সাথে শেয়ার করুন!",
            hashtags = "#ChakmaSong #ChakmaMusicVideo #PahariSong #ViralChakma #MusicVideo2026 #TrendingReels"
        ),
        ViralScriptTemplate(
            id = "good_deeds_viral",
            title = "ভালো কাজের পজিটিভ ভাইরাল ভিডিও (Inspirational)",
            type = "মানবতা ও ভালো কাজ",
            hook = "ছোট একটি ভালো কাজ কিভাবে মানুষের মুখে হাসি ফোটাতে পারে দেখুন...",
            body = "প্রথমে একটি অসহায় মানুষ বা শিশুর বাস্তব কষ্টের মুহূর্ত দেখান, তারপর কোনো অহংকার ছাড়াই অপ্রত্যাশিতভাবে তাকে সাহায্য করুন। ব্যাকগ্রাউন্ডে ইমোশনাল সফট মিউজিক দিন।",
            cta = "আপনিও সমাজে ভালো কাজের আলো ছড়িয়ে দিন। ভিডিওটি শেয়ার করে অন্যকে অনুপ্রাণিত করুন!",
            hashtags = "#GoodDeeds #Humanity #PositiveVibes #HelpingHand #Inspiration #ViralForGood"
        ),
        ViralScriptTemplate(
            id = "tiktok_retention_script",
            title = "টিকটক হাই-রিটেনশন শর্ট ভিডিও ফর্মুলা",
            type = "টিকটক স্পেশাল",
            hook = "কেউ আপনাকে বলবে না, কীভাবে মাত্র ৩ দিনে ভিডিও ভাইরাল করতে হয়...",
            body = "৩টি দ্রুত কার্যকরী টিপস: ১. প্রথম ৩ সেকেন্ডেই প্রশ্নের উত্তর দিন, ২. ব্যাকগ্রাউন্ডে ট্রেন্ডিং সাউন্ড ৩০% ভলিউমে রাখুন, ৩. কমেন্ট বক্সে প্রশ্ন ছুঁড়ে দিন।",
            cta = "আরও সিক্রেট টিপস পেতে আমাদের টেলিগ্রাম চ্যানেলে জয়েন করুন!",
            hashtags = "#TikTokTips #ViralHacks #CreatorGrowth #Monetization #TikTokLite"
        )
    )

    val viralTips = listOf(
        ViralTip(
            id = "cpm_guide",
            title = "ইউটিউব ও ফেসবুকে হাই-সিপিএম ইনকাম স্ট্র্যাটেজি",
            category = "টাকা আয়",
            description = "বাংলাদেশে এবং দেশের বাইরে থেকে কিভাবে বেশি রেভিনিউ পাওয়া যায় তার নিয়মাবলী।",
            fullGuide = "১. লং-ফর্ম ভিডিওতে ৮ মিনিটের বেশি দৈর্ঘ্যের কন্টেন্ট তৈরি করুন যাতে একাধিক মিড-রোল অ্যাড দেওয়া যায়।\n২. বর্ণনামূলক ও এসইও ফ্রেন্ডলি টাইটেল এবং ট্যাগ ব্যবহার করুন।\n৩. নিয়মিত অ্যাডমব সমর্থিত অ্যাপস এবং ল্যান্ডিং পেজে ভিডিও লিংক শেয়ার করুন।"
        ),
        ViralTip(
            id = "telegram_boost",
            title = "টেলিগ্রাম বুস্ট দিয়ে ইনস্ট্যান্ট ভিউ বাড়ানোর ফর্মুলা",
            category = "ভিডিও বুস্ট",
            description = "টেলিগ্রাম গ্রুপ ও চ্যানেলের পাওয়ার কাজে লাগিয়ে নতুন ভিডিও রিলিজের পর দ্রুত র্যাংক করান।",
            fullGuide = "নতুন যেকোনো মিউজিক ভিডিও বা রিল রিলিজ হওয়ার প্রথম ১ ঘণ্টায় টেলিগ্রামে লিংক শেয়ার করুন এবং সাবস্ক্রাইবারদের দিয়ে রিঅ্যাক্ট ও শেয়ার করিয়ে অ্যালগরিদমকে সিগন্যাল দিন।"
        )
    )

    // ==========================================
    // Monetization Actions
    // ==========================================
    fun submitWithdrawal(method: String, accountInfo: String, amountBdt: Double): Boolean {
        val current = _walletBalance.value
        if (amountBdt < 500.0) {
            Toast.makeText(getApplication(), "নূন্যতম উত্তোলনের পরিমাণ ৫০০ টাকা!", Toast.LENGTH_SHORT).show()
            return false
        }
        if (amountBdt > current.availableBdt) {
            Toast.makeText(getApplication(), "অপর্যাপ্ত ব্যালেন্স! আপনার ব্যালেন্স আছে ৳${current.availableBdt.toInt()}", Toast.LENGTH_SHORT).show()
            return false
        }

        val newAvail = current.availableBdt - amountBdt
        val newPending = current.pendingBdt + amountBdt
        _walletBalance.value = current.copy(
            availableBdt = newAvail,
            pendingBdt = newPending,
            availableUsd = newAvail / usdToBdtRate,
            pendingUsd = newPending / usdToBdtRate
        )

        // Save to SharedPrefs
        sharedPrefs.edit().putFloat("wallet_avail_bdt", newAvail.toFloat())
            .putFloat("wallet_pending_bdt", newPending.toFloat()).apply()

        val sdf = SimpleDateFormat("dd MMM yyyy", Locale.getDefault())
        val dateStr = sdf.format(Date())
        val txRef = "TRX" + (100000..999999).random().toString() + "W"

        val newTx = WithdrawalTransaction(
            id = "tx_" + System.currentTimeMillis(),
            date = dateStr,
            method = method,
            accountInfo = accountInfo,
            amountBdt = amountBdt,
            status = WithdrawalStatus.PROCESSING,
            transactionRef = txRef
        )

        _withdrawalHistory.value = listOf(newTx) + _withdrawalHistory.value
        Toast.makeText(getApplication(), "৳${amountBdt.toInt()} উইথড্রয়াল রিকোয়েস্ট সফলভাবে সাবমিট হয়েছে!", Toast.LENGTH_LONG).show()
        return true
    }

    fun applyForCampaign(campaignId: String) {
        val list = _sponsoredCampaigns.value.map {
            if (it.id == campaignId) it.copy(isApplied = true) else it
        }
        _sponsoredCampaigns.value = list
        val campaign = list.find { it.id == campaignId }

        if (campaign != null) {
            // Add to pending earnings
            val current = _walletBalance.value
            val newPending = current.pendingBdt + campaign.payoutBdt
            _walletBalance.value = current.copy(
                pendingBdt = newPending,
                pendingUsd = newPending / usdToBdtRate
            )
            sharedPrefs.edit().putFloat("wallet_pending_bdt", newPending.toFloat()).apply()
            Toast.makeText(getApplication(), "'${campaign.brandName}' ক্যাম্পেইনে আবেদন গৃহীত হয়েছে! ৳${campaign.payoutBdt.toInt()} পেন্ডিং রেভিনিউ যোগ হয়েছে।", Toast.LENGTH_LONG).show()
        }
    }

    fun claimMilestoneReward(milestoneId: String) {
        val list = _milestoneRewards.value.map {
            if (it.id == milestoneId) it.copy(isClaimed = true) else it
        }
        _milestoneRewards.value = list
        val reward = list.find { it.id == milestoneId }

        if (reward != null) {
            val current = _walletBalance.value
            val newAvail = current.availableBdt + reward.rewardBdt
            val newLifetime = current.lifetimeBdt + reward.rewardBdt
            _walletBalance.value = current.copy(
                availableBdt = newAvail,
                lifetimeBdt = newLifetime,
                availableUsd = newAvail / usdToBdtRate,
                lifetimeUsd = newLifetime / usdToBdtRate
            )
            sharedPrefs.edit().putFloat("wallet_avail_bdt", newAvail.toFloat())
                .putFloat("wallet_lifetime_bdt", newLifetime.toFloat()).apply()
            Toast.makeText(getApplication(), "অভিনন্দন! ৳${reward.rewardBdt.toInt()} ক্রিয়েটর বোনাস আপনার ব্যালেন্সে যোগ হয়েছে।", Toast.LENGTH_LONG).show()
        }
    }

    // ==========================================
    // AI Content Generator Actions
    // ==========================================
    fun generateContentWithAi(
        topic: String,
        platformName: String,
        formatType: String,
        positiveFocus: Boolean = true
    ) {
        if (topic.isBlank() || _isGeneratingContent.value) return
        _isGeneratingContent.value = true

        viewModelScope.launch {
            val prompt = """
                Generate a viral, highly positive, and helpful content package for social media.
                Topic: $topic
                Target Platform: $platformName
                Format Requested: $formatType
                Requirement: Emphasize positive impact, constructive values, helpful societal advice, cultural appreciation (e.g. Chakma music & arts), or inspiring life hacks.
                
                Please structure the output with:
                1. 3-Second Hook (পাওয়ারফুল হুক)
                2. Video Script with visual scene instructions, music cues, and timing
                3. Engaging Caption with Call to Action (CTA)
                4. Highly relevant hashtags
                5. Actionable tips to maximize virality and positive community engagement.
            """.trimIndent()

            try {
                val apiKey = BuildConfig.GEMINI_API_KEY
                if (apiKey.isBlank() || apiKey == "MY_GEMINI_API_KEY") {
                    delay(1200)
                    _generatedContent.value = createSmartGeneratedContent(topic, platformName, formatType)
                } else {
                    val request = GeminiRequest(
                        contents = listOf(GeminiContent(parts = listOf(GeminiPart(text = prompt)))),
                        systemInstruction = GeminiContent(parts = listOf(GeminiPart(text = "You are a professional AI viral content generator. Always write in clear, inspiring Bengali (বাংলা) with rich emojis and formatted sections.")))
                    )
                    val response = GeminiClient.apiService.generateContent(apiKey, request)
                    val reply = response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
                    if (!reply.isNullOrBlank()) {
                        _generatedContent.value = parseOrBuildGeneratedContent(topic, platformName, reply)
                    } else {
                        _generatedContent.value = createSmartGeneratedContent(topic, platformName, formatType)
                    }
                }
            } catch (e: Exception) {
                _generatedContent.value = createSmartGeneratedContent(topic, platformName, formatType)
            } finally {
                _isGeneratingContent.value = false
            }
        }
    }

    private fun createSmartGeneratedContent(topic: String, platform: String, format: String): GeneratedAiContent {
        val isMusic = topic.contains("চাকমা") || topic.contains("গান") || topic.contains("music", true)
        val isGoodDeeds = topic.contains("ভালো কাজ") || topic.contains("মানবতা") || topic.contains("সাহায্য")

        val hook = if (isMusic) {
            "গানটির এই সুরটা শুনলে আপনিও বারবার শুনতে বাধ্য হবেন... 🎶✨"
        } else if (isGoodDeeds) {
            "মাত্র একটি ছোট ভালো কাজ মানুষের মুখে কত বড় হাসি ফোটাতে পারে দেখুন... 💖"
        } else {
            "কেউ আপনাকে বলবে না, কীভাবে সহজে এই অসাধারণ কাজটি করা যায়... 🚀"
        }

        val script = """
            ⏱️ [০-৩ সেকেন্ড]:
            • ভিজ্যুয়াল: ফাস্ট জুম-ইন শট, স্ক্রিনে বোল্ড টেক্সট: '$hook'
            • অডিও: আকর্ষণীয় ব্যাকগ্রাউন্ড মিউজিক (Chakma Flute / Cinematic Soft Piano)
            
            ⏱️ [৩-১৫ সেকেন্ড]:
            • ভিজ্যুয়াল: মূল বিষয়টি স্পষ্টভাবে উপস্থাপন করুন। কোনো অতিরিক্ত ভণিতা ছাড়াই সরাসরি মূল অ্যাকশন/দৃশ্য দেখান।
            • ক্যামেরা: ক্লোজ-আপ থেকে ওয়াইড অ্যাঙ্গেল ড্রোন বা প্রাকৃতিক আলোর সিনেমাটিক শট।
            
            ⏱️ [১৫-৩০ সেকেন্ড (CTA)]:
            • ভিজ্যুয়াল: ক্রিয়েটর হাসিমুখে স্ক্রিনে আসছেন অথবা চমৎকার এন্ডিং ফ্রেম।
            • স্পিচ/টেক্সট: "ভালো লাগলে শেয়ার করুন এবং আপনার পছন্দের অংশটি কমেন্টে জানান!"
        """.trimIndent()

        val caption = if (isMusic) {
            "পাহাড়ের মিষ্টি সুর ও ভালোবাসার ছোঁয়া 🎶 আপনার পছন্দের মানুষের সাথে শেয়ার করুন এবং ইউটিউবে সম্পূর্ণ ভিডিওটি দেখতে ভুলবেন না! ❤️👇"
        } else if (isGoodDeeds) {
            "সমাজে ভালো কাজের কোনো বিকল্প নেই। আসুন আমরা সবাই মিলে একে অপরের পাশে দাঁড়াই। বার্তাটি ভালো লাগলে শেয়ার করে অন্যকে অনুপ্রাণিত করুন! 🌟🤝"
        } else {
            "$topic নিয়ে সেরা কিছু টিপস ও ট্রিকস! আপনার কাছে কোনটি সবচেয়ে দরকারি মনে হলো? কমেন্টে মতামত দিন 🔥"
        }

        val hashtags = if (isMusic) {
            "#ChakmaMusicVideo #ChakmaSong #PahariMusic #TrendingReels #TikTokViral #MusicVideo2026 #ViralSongs"
        } else if (isGoodDeeds) {
            "#GoodDeeds #HumanityFirst #PositiveContent #Inspiration #SpreadingLove #ViralForGood #Bangladesh"
        } else {
            "#CreatorTips #ViralShorts #Trending2026 #ContentCreation #OnlineIncome #TikTokTips"
        }

        val tips = "১. ভিডিও আপলোডের সাথে সাথে টেলিগ্রাম চ্যানেলে শেয়ার করে প্রাথমিক বুস্ট নিন।\n২. কমেন্ট বক্সে প্রথম কমেন্টটি পিন করে দর্শকদের সাথে এনগেজ হোন।"

        return GeneratedAiContent(
            id = UUID.randomUUID().toString(),
            topic = topic,
            platform = platform,
            hook = hook,
            videoScript = script,
            caption = caption,
            hashtags = hashtags,
            positiveImpactScore = (95..99).random(),
            helpfulTips = tips
        )
    }

    private fun parseOrBuildGeneratedContent(topic: String, platform: String, aiRawText: String): GeneratedAiContent {
        return GeneratedAiContent(
            id = UUID.randomUUID().toString(),
            topic = topic,
            platform = platform,
            hook = "ভিডিওর প্রথম ৩ সেকেন্ডেই দর্শকদের মুগ্ধ করার মাস্টার হুক 🌟",
            videoScript = aiRawText,
            caption = "$topic | ভিডিওটি ভালো লাগলে অবশ্যই লাইক ও বন্ধুদের সাথে শেয়ার করুন! 🚀✨",
            hashtags = "#ViralContent #Trending #CreatorHub #ChakmaMusicVideo #GoodDeeds #Monetization",
            positiveImpactScore = 98,
            helpfulTips = "এই কন্টেন্টটি পোস্ট করার পর কমেন্টে দর্শকদের প্রশ্ন করুন এবং টেলিগ্রামে লিংক বুস্ট করুন।"
        )
    }

    // ==========================================
    // Cross-Platform Sharing & Deep-Linking
    // ==========================================
    fun shareDirectToPlatform(
        context: Context,
        platform: SocialPlatform,
        caption: String,
        hashtags: String,
        url: String = ""
    ) {
        val fullShareText = if (url.isNotBlank()) {
            "$caption\n\n$hashtags\n\n🔗 দেখুন: $url"
        } else {
            "$caption\n\n$hashtags"
        }

        // Copy to clipboard for easy paste
        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = ClipData.newPlainText("Share Content", fullShareText)
        clipboard.setPrimaryClip(clip)

        val (packageName, webFallback) = when (platform) {
            SocialPlatform.TIKTOK -> Pair("com.zhiliaoapp.musically", "https://vm.tiktok.com/ZSVw2r989/")
            SocialPlatform.YOUTUBE -> Pair("com.google.android.youtube", "https://www.youtube.com/@Chakma-music-Video")
            SocialPlatform.FACEBOOK -> Pair("com.facebook.katana", "https://www.facebook.com/profile.php?id=61593411089547")
            SocialPlatform.TELEGRAM -> Pair("org.telegram.messenger", "https://t.me/boost/JuwelChakma989")
        }

        try {
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, fullShareText)
                setPackage(packageName)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            Toast.makeText(context, "${platform.displayName}-এ শেয়ার ও ক্যাপশন ক্লিপবোর্ডে কপি হয়েছে!", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            // If package not found, launch web or standard chooser
            try {
                val chooserIntent = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_TEXT, fullShareText)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(Intent.createChooser(chooserIntent, "${platform.displayName}-এ শেয়ার করুন"))
                Toast.makeText(context, "ক্যাপশন কপি হয়েছে! অ্যাপ বেছে নিয়ে পেস্ট করুন।", Toast.LENGTH_SHORT).show()
            } catch (ex: Exception) {
                openUrl(context, webFallback)
            }
        }
    }

    fun setDiscoveryFilter(platform: SocialPlatform?) {
        _discoveryFilter.value = platform
    }

    // ==========================================
    // Core Helpers
    // ==========================================
    fun updateBannerAdUnitId(newId: String) {
        _bannerAdUnitId.value = newId
        sharedPrefs.edit().putString("banner_ad_unit_id", newId).apply()
        Toast.makeText(getApplication(), "AdMob ব্যানার আইডি সংরক্ষণ করা হয়েছে!", Toast.LENGTH_SHORT).show()
    }

    fun toggleAdTestMode(isTest: Boolean) {
        _isAdTestMode.value = isTest
        sharedPrefs.edit().putBoolean("ad_test_mode", isTest).apply()
    }

    fun setCalculatorViews(views: Long) {
        _calculatorViews.value = views
    }

    fun setCalculatorPlatform(platform: String) {
        _calculatorPlatform.value = platform
        when (platform) {
            "YouTube (লং ভিডিও)" -> _calculatorCpm.value = 2.0f
            "YouTube (শর্টস)" -> _calculatorCpm.value = 0.08f
            "TikTok (ক্রিয়েটর রিওয়ার্ডস)" -> _calculatorCpm.value = 0.65f
            "Facebook (ইন-স্ট্রিম / রিলস)" -> _calculatorCpm.value = 1.20f
            "AdMob (ব্যানার ও অ্যাপ অ্যাডস)" -> _calculatorCpm.value = 1.80f
            else -> _calculatorCpm.value = 1.0f
        }
    }

    fun setCalculatorCpm(cpm: Float) {
        _calculatorCpm.value = cpm
    }

    fun toggleChecklistItem(key: String) {
        val current = _checklistState.value.toMutableMap()
        current[key] = !(current[key] ?: false)
        _checklistState.value = current
    }

    fun openUrl(context: Context, url: String) {
        try {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(context, "লিংক ওপেন করা যায়নি: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    fun copyToClipboard(context: Context, label: String, text: String) {
        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = ClipData.newPlainText(label, text)
        clipboard.setPrimaryClip(clip)
        Toast.makeText(context, "কপি করা হয়েছে!", Toast.LENGTH_SHORT).show()
    }

    fun shareText(context: Context, title: String, text: String) {
        try {
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_SUBJECT, title)
                putExtra(Intent.EXTRA_TEXT, text)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(Intent.createChooser(intent, "শেয়ার করুন").apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            })
        } catch (e: Exception) {
            Toast.makeText(context, "শেয়ার করতে সমস্যা হয়েছে", Toast.LENGTH_SHORT).show()
        }
    }

    fun sendAiPrompt(prompt: String) {
        val trimmed = prompt.trim()
        if (trimmed.isBlank() || _isAiLoading.value) return

        val userMsg = AiChatMessage(
            id = UUID.randomUUID().toString(),
            text = trimmed,
            isUser = true
        )
        _chatMessages.value = _chatMessages.value + userMsg
        _isAiLoading.value = true

        viewModelScope.launch {
            val systemPrompt = """
                You are 'Viral Creator AI Assistant' (ভাইরাল ক্রিয়েটর এআই সহকারী).
                Your goal is to empower content creators in Bangladesh and worldwide, specifically supporting Chakma music, cultural content, TikTok shorts, YouTube channels, Facebook Reels, and Telegram viral growth.
                You provide helpful, actionable, high-retention video hooks, scripts, positive viral ideas for doing good in society (ভালো কাজের আইডিয়া), monetization blueprints, tag strategies, and AdMob optimization guidance.
                Always respond warmly, politely, and predominantly in clear Bengali (বাংলা), formatted with neat bullet points, emojis, and step-by-step instructions.
            """.trimIndent()

            try {
                val apiKey = BuildConfig.GEMINI_API_KEY
                if (apiKey.isBlank() || apiKey == "MY_GEMINI_API_KEY") {
                    val fallbackResponse = getSmartCreatorResponse(trimmed)
                    val aiMsg = AiChatMessage(
                        id = UUID.randomUUID().toString(),
                        text = fallbackResponse,
                        isUser = false
                    )
                    _chatMessages.value = _chatMessages.value + aiMsg
                } else {
                    val request = GeminiRequest(
                        contents = listOf(GeminiContent(parts = listOf(GeminiPart(text = trimmed)))),
                        systemInstruction = GeminiContent(parts = listOf(GeminiPart(text = systemPrompt)))
                    )
                    val response = GeminiClient.apiService.generateContent(apiKey, request)
                    val replyText = response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
                        ?: getSmartCreatorResponse(trimmed)

                    val aiMsg = AiChatMessage(
                        id = UUID.randomUUID().toString(),
                        text = replyText,
                        isUser = false
                    )
                    _chatMessages.value = _chatMessages.value + aiMsg
                }
            } catch (e: Exception) {
                val offlineReply = getSmartCreatorResponse(trimmed)
                val aiMsg = AiChatMessage(
                    id = UUID.randomUUID().toString(),
                    text = offlineReply,
                    isUser = false
                )
                _chatMessages.value = _chatMessages.value + aiMsg
            } finally {
                _isAiLoading.value = false
            }
        }
    }

    private fun getSmartCreatorResponse(prompt: String): String {
        val p = prompt.lowercase()
        return when {
            p.contains("চাকমা") || p.contains("music") || p.contains("গান") || p.contains("ভিডিও") -> {
                """
                🎵 **চাকমা মিউজিক ভিডিও ভাইরাল করার আলটিমেট স্ট্র্যাটেজি:**

                ১. **৩ সেকেন্ড হুক:** ভিডিও শুরুতেই গানের সবচেয়ে মধুর বা এনার্জেটিক লিরিক লাইনটি বাজান। স্ক্রিনে লিখুন: *"এই গানটি শুনলে আপনার মন ভালো হয়ে যাবেই! 🎶"*
                ২. **কালচারাল ও প্রাকৃতিক সৌন্দর্য:** চাকমা সংস্কৃতির ঐতিহ্যবাহী পোশাক, পাহাড়ি নদী ও প্রাকৃতিক ব্যাকড্রপের সুন্দর সিনেমাটিক শট দিন।
                ৩. **টিকটক ও রিলস ট্রেন্ড:** পুরো গান থেকে ১৫ সেকেন্ডের একটি ক্যাচি ক্লিপ কেটে টিকটকে নিজস্ব অরিজিনাল অডিও হিসেবে পোস্ট করুন।
                ৪. **ভাইরাল হ্যাশট্যাগ:** `#ChakmaSong #ChakmaMusicVideo #PahariVibes #ViralReels #TrendingSong`
                ৫. **টেলিগ্রাম বুস্ট:** রিলিজের পর টেলিগ্রাম গ্রুপে লিংক দিয়ে সবাইকে শেয়ার করতে বলুন!
                """.trimIndent()
            }
            p.contains("ভালো কাজ") || p.contains("সাহায্য") || p.contains("উপকার") || p.contains("মানবতা") -> {
                """
                🌟 **ভালো কাজ ও সমাজকল্যাণমূলক ভাইরাল কন্টেন্ট আইডিয়া:**

                ১. **পথশিশুদের একদিনের আনন্দ:** সুবিধাবঞ্চিত শিশুদের নতুন জামা বা পছন্দের খাবার উপহার দেওয়ার সৎ ও মানবিক ভিডিও তৈরি করুন।
                ২. **পাহাড়ের ঐতিহ্য সংরক্ষণ:** পাহাড়ি এলাকার প্রাচীন হস্তশিল্প বা গাছ লাগানোর সচেতনতামূলক উদ্যোগ তুলে ধরুন।
                ৩. **অসহায় শিল্পীদের পাশে দাঁড়ানো:** গ্রামীণ বা লোকজ বাদ্যযন্ত্র বাজানো প্রবীণ শিল্পীদের প্রতিভা ইন্টারনেটে তুলে ধরে তাদের জন্য সহায়তার আহ্বান জানান।
                ৪. **পজিটিভ মেসেজ:** ভিডিও শেষে বলুন: *"ভালো কাজের এই বার্তাটি ছড়িয়ে দিতে শেয়ার করুন।"*
                """.trimIndent()
            }
            p.contains("টাকা") || p.contains("আয়") || p.contains("ইনকাম") || p.contains("earning") || p.contains("উইথড্র") || p.contains("withdraw") -> {
                """
                💰 **ইন-অ্যাপ মনিটাইজেশন ও ইনকাম উইথড্রয়াল গাইড:**

                ১. **পপুলার কন্টেন্ট রিওয়ার্ড:** আপনার কন্টেন্টে ১০০K+ ভিউ হলে ক্রিয়েটর পুল থেকে ক্যাশ বোনাস দাবি করুন।
                ২. **স্পন্সরড ক্যাম্পেইন:** 'আয় ও মনিটাইজেশন' ট্যাব থেকে ব্র্যান্ড ক্যাম্পেইনে আবেদন করে প্রতি ভিডিওতে ৳৮,০০০ - ৳২০,০০০ পর্যন্ত আয় করুন।
                ৩. **ভিআইপি ফ্যান সাবস্ক্রিপশন:** আপনার ফলোয়ারদের এক্সক্লুসিভ গান ও ভিডিও লিরিক্স দিয়ে মাসিক সাবস্ক্রিপশন অফার করুন।
                ৪. **উইথড্রয়াল মাধ্যম:** বিকাশ (bKash), নগদ (Nagad), ব্যাংক ট্রান্সফার অথবা ক্রিপ্টো/USDT-এর মাধ্যমে সর্বনিম্ন ৫০০ টাকা হলেই সরাসরি ক্যাশআউট করুন।
                """.trimIndent()
            }
            p.contains("টিকটক") || p.contains("tiktok") || p.contains("ভিউ") || p.contains("viral") -> {
                """
                🚀 **টিকটক ও রিলস এ লাখ ভিউ পাওয়ার গোপন ট্রিকস:**

                • **প্রথম ৩ সেকেন্ডে ড্রপ বন্ধ করুন:** অদ্ভুত কোনো মুভমেন্ট, প্রশ্নবোধক টেক্সট বা আকর্ষণীয় সাউন্ড দিয়ে মনোযোগ ধরে রাখুন।
                • **ট্রেন্ডিং অডিও মাস্ট:** টিকটকের সার্চে গিয়ে ভাইরাল সাউন্ড যুক্ত করে অরিজিনাল সাউন্ড ৫০% ও ট্রেন্ডিং সাউন্ড ১০% ভলিউমে রাখুন।
                • **পোস্ট করার সেরা সময়:** দুপুর ১:০০-২:০০টা এবং সন্ধ্যা ৭:০০-৯:৩০টা।
                • **ক্যাপশনে কল-টু-অ্যাকশন (CTA):** *"আপনার কার এই গানটি সবচেয়ে প্রিয়? কমেন্টে জানান!"*
                """.trimIndent()
            }
            else -> {
                """
                ✨ **ভাইরাল ক্রিয়েটর টিপস ও গাইড:**

                সফল কন্টেন্ট ক্রিয়েটর হতে এই ৩টি নিয়ম মেনে চলুন:
                ১. **ধারাবাহিকতা (Consistency):** সপ্তাহে অন্তত ৩-৪টি কোয়ালিটি রিলস/শর্টস আপলোড করুন।
                ২. **অডিয়েন্স কানেকশন:** আপনার ফেসবুক ও টেলিগ্রাম কমিউনিটির সাথে সরাসরি যুক্ত থাকুন।
                ৩. **মাল্টি-প্ল্যাটফর্ম শেয়ারিং:** ইউটিউব, টিকটক, ফেসবুক ও টেলিগ্রামে একই কন্টেন্ট অপ্টিমাইজ করে শেয়ার করুন।

                অন্য যেকোনো কন্টেন্ট আইডিয়া বা স্ক্রিপ্ট লাগলে নিচে টাইপ করুন!
                """.trimIndent()
            }
        }
    }
}
