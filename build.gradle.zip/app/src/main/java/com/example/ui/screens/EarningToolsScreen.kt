package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.AttachMoney
import androidx.compose.material.icons.filled.BusinessCenter
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.CardGiftcard
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Diamond
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.Payment
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.RocketLaunch
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.PrimaryTabRow
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.CreatorMilestoneReward
import com.example.data.model.PremiumSubscriptionTier
import com.example.data.model.SponsoredCampaign
import com.example.data.model.WithdrawalMethod
import com.example.data.model.WithdrawalStatus
import com.example.data.model.WithdrawalTransaction
import com.example.ui.ViralViewModel
import com.example.ui.components.AdMobBannerView
import com.example.ui.theme.ElegantDarkAccentGreen
import com.example.ui.theme.ElegantDarkBorder
import com.example.ui.theme.ElegantDarkPrimary
import com.example.ui.theme.ElegantDarkSurface
import com.example.ui.theme.ElegantDarkSurfaceVariant
import com.example.ui.theme.ElegantDarkText
import com.example.ui.theme.ElegantDarkTextMuted
import com.example.ui.theme.ElegantDarkTextSecondary
import java.text.NumberFormat
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EarningToolsScreen(
    viewModel: ViralViewModel,
    bannerAdUnitId: String,
    isTestMode: Boolean,
    modifier: Modifier = Modifier
) {
    val wallet by viewModel.walletBalance.collectAsState()
    val sponsoredCampaigns by viewModel.sponsoredCampaigns.collectAsState()
    val premiumTiers by viewModel.premiumTiers.collectAsState()
    val milestoneRewards by viewModel.milestoneRewards.collectAsState()
    val withdrawalHistory by viewModel.withdrawalHistory.collectAsState()

    var selectedSectionTab by remember { mutableIntStateOf(0) }
    var showWithdrawDialog by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("earning_screen_column"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // 1. Wallet & Live Earnings Card
        item {
            WalletOverviewCard(
                availableBdt = wallet.availableBdt,
                pendingBdt = wallet.pendingBdt,
                lifetimeBdt = wallet.lifetimeBdt,
                availableUsd = wallet.availableUsd,
                onOpenWithdraw = { showWithdrawDialog = true }
            )
        }

        // Live Banner
        item {
            AdMobBannerView(adUnitId = bannerAdUnitId, isTestMode = isTestMode)
        }

        // 2. Monetization Strategy Tabs
        item {
            PrimaryTabRow(
                selectedTabIndex = selectedSectionTab,
                containerColor = ElegantDarkSurface,
                contentColor = ElegantDarkPrimary,
                modifier = Modifier
                    .clip(RoundedCornerShape(14.dp))
                    .border(1.dp, ElegantDarkBorder, RoundedCornerShape(14.dp))
            ) {
                Tab(
                    selected = selectedSectionTab == 0,
                    onClick = { selectedSectionTab = 0 },
                    text = { Text("স্পন্সরড ডিল", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                    modifier = Modifier.testTag("tab_sponsorships")
                )
                Tab(
                    selected = selectedSectionTab == 1,
                    onClick = { selectedSectionTab = 1 },
                    text = { Text("ফ্যান সাবস্ক্রিপশন", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                    modifier = Modifier.testTag("tab_subscriptions")
                )
                Tab(
                    selected = selectedSectionTab == 2,
                    onClick = { selectedSectionTab = 2 },
                    text = { Text("কন্টেন্ট পুল", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                    modifier = Modifier.testTag("tab_creator_pool")
                )
                Tab(
                    selected = selectedSectionTab == 3,
                    onClick = { selectedSectionTab = 3 },
                    text = { Text("উইথড্র হিস্ট্রি", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                    modifier = Modifier.testTag("tab_history")
                )
            }
        }

        // 3. Tab Contents
        when (selectedSectionTab) {
            0 -> {
                // Sponsored Campaigns
                item {
                    SectionHeaderTag(
                        icon = Icons.Default.BusinessCenter,
                        title = "স্পন্সরড ক্যাম্পেইন ও ব্র্যান্ড ডিল",
                        subtitle = "ব্র্যান্ডের সাথে যুক্ত হয়ে গান ও ভিডিও প্রোমোশনে অংশ নিন"
                    )
                }
                items(sponsoredCampaigns) { campaign ->
                    SponsoredCampaignCard(
                        campaign = campaign,
                        onApply = { viewModel.applyForCampaign(campaign.id) }
                    )
                }
            }
            1 -> {
                // Fan Subscriptions & VIP Pass
                item {
                    SectionHeaderTag(
                        icon = Icons.Default.Diamond,
                        title = "প্রিমিয়াম ফিচার ও ফ্যান সাবস্ক্রিপশন",
                        subtitle = "ফলোয়ারদের এক্সক্লুসিভ গান, অডিও ফাইল ও ভিআইপি এক্সেস দিন"
                    )
                }
                items(premiumTiers) { tier ->
                    PremiumTierCard(tier = tier)
                }
            }
            2 -> {
                // Creator Views Reward Pool & Milestones
                item {
                    SectionHeaderTag(
                        icon = Icons.Default.CardGiftcard,
                        title = "পপুলার কন্টেন্ট রিওয়ার্ড পুল (Creator Bonus)",
                        subtitle = "ভিডিও ভিউ মাইলস্টোন পূর্ণ হলে সরাসরি ক্যাশ বোনাস পান"
                    )
                }
                items(milestoneRewards) { reward ->
                    MilestoneRewardCard(
                        reward = reward,
                        onClaim = { viewModel.claimMilestoneReward(reward.id) }
                    )
                }
            }
            3 -> {
                // Withdrawal History
                item {
                    SectionHeaderTag(
                        icon = Icons.Default.History,
                        title = "উইথড্রয়াল ও ক্যাশআউট হিস্ট্রি",
                        subtitle = "বিকাশ, নগদ ও ব্যাংকে প্রেরিত টাকার স্ট্যাটাস দেখুন"
                    )
                }
                items(withdrawalHistory) { tx ->
                    WithdrawalTxCard(tx = tx)
                }
            }
        }

        // 4. Live Revenue Calculator
        item {
            EarningCalculatorCard(viewModel = viewModel)
        }

        // 5. Pre-flight Viral Checklist
        item {
            ViralChecklistCard(viewModel = viewModel)
        }
    }

    // Withdrawal Modal Dialog
    if (showWithdrawDialog) {
        WithdrawalDialog(
            availableBdt = wallet.availableBdt,
            methods = viewModel.withdrawalMethods,
            onDismiss = { showWithdrawDialog = false },
            onSubmit = { method, account, amount ->
                val success = viewModel.submitWithdrawal(method, account, amount)
                if (success) {
                    showWithdrawDialog = false
                }
            }
        )
    }
}

@Composable
fun WalletOverviewCard(
    availableBdt: Double,
    pendingBdt: Double,
    lifetimeBdt: Double,
    availableUsd: Double,
    onOpenWithdraw: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(22.dp))
            .border(1.dp, ElegantDarkAccentGreen.copy(alpha = 0.4f), RoundedCornerShape(22.dp))
            .testTag("wallet_overview_card"),
        colors = CardDefaults.cardColors(containerColor = ElegantDarkSurface)
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(ElegantDarkAccentGreen.copy(alpha = 0.15f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.AccountBalanceWallet,
                            contentDescription = null,
                            tint = ElegantDarkAccentGreen,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "ক্রিয়েটর ওয়ালেট ও ইনকাম",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = ElegantDarkText
                        )
                        Text(
                            text = "রিয়েল-টাইম রেভিনিউ ট্র্যাকার",
                            fontSize = 11.sp,
                            color = ElegantDarkTextMuted
                        )
                    }
                }

                Surface(
                    color = ElegantDarkAccentGreen.copy(alpha = 0.15f),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Verified, contentDescription = null, tint = ElegantDarkAccentGreen, modifier = Modifier.size(12.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "উইথড্র সক্রিয়",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = ElegantDarkAccentGreen
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Main Balance Highlight
            Text(
                text = "উত্তোলনযোগ্য বর্তমান ব্যালেন্স:",
                fontSize = 12.sp,
                color = ElegantDarkTextMuted
            )

            Row(
                verticalAlignment = Alignment.Bottom,
                modifier = Modifier.padding(vertical = 4.dp)
            ) {
                Text(
                    text = "৳" + NumberFormat.getNumberInstance(Locale.US).format(availableBdt.toInt()),
                    fontSize = 32.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = ElegantDarkAccentGreen
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "($${String.format(Locale.US, "%.2f", availableUsd)} USD)",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium,
                    color = ElegantDarkTextMuted,
                    modifier = Modifier.padding(bottom = 4.dp)
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Sub Stats Row (Pending & Lifetime)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(ElegantDarkSurfaceVariant)
                    .padding(12.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(text = "পেন্ডিং আয় (ক্যাম্পেইন):", fontSize = 11.sp, color = ElegantDarkTextMuted)
                    Text(
                        text = "৳" + NumberFormat.getNumberInstance(Locale.US).format(pendingBdt.toInt()),
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFFFFB300)
                    )
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text(text = "সর্বমোট আয় (Lifetime):", fontSize = 11.sp, color = ElegantDarkTextMuted)
                    Text(
                        text = "৳" + NumberFormat.getNumberInstance(Locale.US).format(lifetimeBdt.toInt()),
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = ElegantDarkText
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Withdraw Button
            Button(
                onClick = onOpenWithdraw,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(46.dp)
                    .testTag("btn_open_withdraw_dialog"),
                colors = ButtonDefaults.buttonColors(
                    containerColor = ElegantDarkAccentGreen,
                    contentColor = Color(0xFF00381B)
                ),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(Icons.Default.Payment, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "টাকা উইথড্র করুন (bKash / Nagad / Bank)",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
fun SponsoredCampaignCard(
    campaign: SponsoredCampaign,
    onApply: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .border(1.dp, ElegantDarkBorder, RoundedCornerShape(18.dp))
            .testTag("campaign_card_${campaign.id}"),
        colors = CardDefaults.cardColors(containerColor = ElegantDarkSurface)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    color = ElegantDarkPrimary.copy(alpha = 0.15f),
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Text(
                        text = campaign.category,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = ElegantDarkPrimary,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }

                Surface(
                    color = ElegantDarkAccentGreen.copy(alpha = 0.15f),
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Text(
                        text = "পেমেন্ট: ৳${campaign.payoutBdt.toInt()}",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = ElegantDarkAccentGreen,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = campaign.title,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = ElegantDarkText
            )

            Text(
                text = "ব্র্যান্ড: ${campaign.brandName} • শেষ তারিখ: ${campaign.deadline}",
                fontSize = 11.sp,
                color = ElegantDarkTextMuted,
                modifier = Modifier.padding(vertical = 2.dp)
            )

            Spacer(modifier = Modifier.height(8.dp))

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(ElegantDarkSurfaceVariant)
                    .padding(10.dp)
            ) {
                Text(
                    text = "📌 শর্তাবলী: ${campaign.requirements}",
                    fontSize = 11.sp,
                    color = ElegantDarkTextSecondary,
                    lineHeight = 16.sp
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "খালি স্লট: ${campaign.spotsLeft} জন",
                    fontSize = 11.sp,
                    color = Color(0xFFFFB300),
                    fontWeight = FontWeight.SemiBold
                )

                if (campaign.isApplied) {
                    Surface(
                        color = ElegantDarkAccentGreen.copy(alpha = 0.2f),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.Check, contentDescription = null, tint = ElegantDarkAccentGreen, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("আবেদন সম্পন্ন", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = ElegantDarkAccentGreen)
                        }
                    }
                } else {
                    Button(
                        onClick = onApply,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = ElegantDarkPrimary,
                            contentColor = Color(0xFF381E72)
                        ),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
                        modifier = Modifier.testTag("btn_apply_${campaign.id}")
                    ) {
                        Text("আবেদন করুন", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun PremiumTierCard(tier: PremiumSubscriptionTier) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .border(1.dp, ElegantDarkBorder, RoundedCornerShape(18.dp))
            .testTag("tier_card_${tier.id}"),
        colors = CardDefaults.cardColors(containerColor = ElegantDarkSurface)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = tier.title,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = ElegantDarkText
                )

                Text(
                    text = "৳${tier.priceBdt.toInt()} / ${tier.billingCycle}",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFFFFB300)
                )
            }

            Text(
                text = "সক্রিয় ফ্যান গ্রাহক: ${tier.activeSubscribers} জন",
                fontSize = 11.sp,
                color = ElegantDarkTextMuted,
                modifier = Modifier.padding(vertical = 4.dp)
            )

            Spacer(modifier = Modifier.height(8.dp))

            tier.perks.forEach { perk ->
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(vertical = 2.dp)
                ) {
                    Icon(Icons.Default.Star, contentDescription = null, tint = ElegantDarkPrimary, modifier = Modifier.size(13.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(text = perk, fontSize = 11.sp, color = ElegantDarkTextSecondary)
                }
            }
        }
    }
}

@Composable
fun MilestoneRewardCard(
    reward: CreatorMilestoneReward,
    onClaim: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .border(1.dp, ElegantDarkBorder, RoundedCornerShape(18.dp))
            .testTag("milestone_card_${reward.id}"),
        colors = CardDefaults.cardColors(containerColor = ElegantDarkSurface)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = reward.title,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = ElegantDarkText
                )
                Text(
                    text = "৳${reward.rewardBdt.toInt()} বোনাস",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = ElegantDarkAccentGreen
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            LinearProgressIndicator(
                progress = { reward.progressPercent.coerceIn(0f, 1f) },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(6.dp)
                    .clip(CircleShape),
                color = ElegantDarkAccentGreen,
                trackColor = ElegantDarkSurfaceVariant
            )

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "টার্গেট: ${reward.targetViews} (${(reward.progressPercent * 100).toInt()}% সম্পন্ন)",
                    fontSize = 11.sp,
                    color = ElegantDarkTextMuted
                )

                if (reward.isClaimed) {
                    Text(text = "ক্লেইম সম্পন্ন ✅", fontSize = 11.sp, color = ElegantDarkAccentGreen, fontWeight = FontWeight.Bold)
                } else if (reward.progressPercent >= 1.0f) {
                    Button(
                        onClick = onClaim,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = ElegantDarkAccentGreen,
                            contentColor = Color(0xFF00381B)
                        ),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)
                    ) {
                        Text("ক্লেইম করুন", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                } else {
                    Text(text = "চলমান ⏳", fontSize = 11.sp, color = Color(0xFFFFB300))
                }
            }
        }
    }
}

@Composable
fun WithdrawalTxCard(tx: WithdrawalTransaction) {
    val statusColor = Color(tx.status.colorHex)

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .border(1.dp, ElegantDarkBorder, RoundedCornerShape(16.dp)),
        colors = CardDefaults.cardColors(containerColor = ElegantDarkSurface)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text(text = tx.method, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = ElegantDarkText)
                Text(text = "${tx.accountInfo} • ${tx.date}", fontSize = 11.sp, color = ElegantDarkTextMuted)
                Text(text = "TxID: ${tx.transactionRef}", fontSize = 10.sp, color = ElegantDarkTextMuted)
            }

            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = "৳${tx.amountBdt.toInt()}",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = ElegantDarkAccentGreen
                )
                Surface(
                    color = statusColor.copy(alpha = 0.15f),
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Text(
                        text = tx.status.label,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = statusColor,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun WithdrawalDialog(
    availableBdt: Double,
    methods: List<WithdrawalMethod>,
    onDismiss: () -> Unit,
    onSubmit: (method: String, account: String, amount: Double) -> Unit
) {
    var selectedMethod by remember { mutableStateOf(methods.first()) }
    var accountInput by remember { mutableStateOf("") }
    var amountInput by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Payment, contentDescription = null, tint = ElegantDarkAccentGreen)
                Spacer(modifier = Modifier.width(8.dp))
                Text(text = "টাকা উত্তোলন (Withdrawal)", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = ElegantDarkText)
            }
        },
        text = {
            Column {
                Text(
                    text = "আপনার ব্যালেন্স: ৳${availableBdt.toInt()} (নূন্যতম ৫০০ টাকা)",
                    fontSize = 12.sp,
                    color = ElegantDarkAccentGreen,
                    fontWeight = FontWeight.SemiBold
                )

                Spacer(modifier = Modifier.height(12.dp))

                Text(text = "পেমেন্ট মেথড বাছাই করুন:", fontSize = 12.sp, color = ElegantDarkTextMuted)
                Spacer(modifier = Modifier.height(6.dp))

                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(methods) { m ->
                        val isSelected = selectedMethod.id == m.id
                        Surface(
                            color = if (isSelected) Color(m.colorHex).copy(alpha = 0.2f) else ElegantDarkSurfaceVariant,
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .clickable { selectedMethod = m }
                                .border(
                                    1.dp,
                                    if (isSelected) Color(m.colorHex) else ElegantDarkBorder,
                                    RoundedCornerShape(8.dp)
                                )
                        ) {
                            Text(
                                text = m.name,
                                fontSize = 11.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                color = if (isSelected) Color(m.colorHex) else ElegantDarkText,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = accountInput,
                    onValueChange = { accountInput = it },
                    label = { Text("অ্যাকাউন্ট / ওয়ালেট নম্বর") },
                    placeholder = { Text(selectedMethod.placeholder, fontSize = 11.sp) },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = ElegantDarkPrimary,
                        unfocusedBorderColor = ElegantDarkBorder
                    )
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = amountInput,
                    onValueChange = { amountInput = it },
                    label = { Text("উত্তোলনের পরিমাণ (BDT)") },
                    placeholder = { Text("যেমন: 1000", fontSize = 11.sp) },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = ElegantDarkPrimary,
                        unfocusedBorderColor = ElegantDarkBorder
                    )
                )

                if (errorMessage != null) {
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(text = errorMessage!!, color = Color(0xFFFF5252), fontSize = 11.sp)
                }

                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "প্রসেসিং সময়: ${selectedMethod.processingTime} • ফি: ${selectedMethod.feePercent}",
                    fontSize = 10.sp,
                    color = ElegantDarkTextMuted
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val amount = amountInput.toDoubleOrNull()
                    if (accountInput.isBlank()) {
                        errorMessage = "অনুগ্রহ করে অ্যাকাউন্ট নম্বর দিন"
                    } else if (amount == null || amount < 500.0) {
                        errorMessage = "নূন্যতম উত্তোলন ৫০০ টাকা"
                    } else if (amount > availableBdt) {
                        errorMessage = "অপর্যাপ্ত ব্যালেন্স!"
                    } else {
                        onSubmit(selectedMethod.name, accountInput, amount)
                    }
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = ElegantDarkAccentGreen,
                    contentColor = Color(0xFF00381B)
                )
            ) {
                Text("নিশ্চিত করুন", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("বাতিল", color = ElegantDarkTextMuted)
            }
        },
        containerColor = ElegantDarkSurface
    )
}

@Composable
fun SectionHeaderTag(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, subtitle: String) {
    Column(modifier = Modifier.padding(top = 4.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, contentDescription = null, tint = ElegantDarkPrimary, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text(text = title, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = ElegantDarkText)
        }
        Text(text = subtitle, fontSize = 11.sp, color = ElegantDarkTextMuted, modifier = Modifier.padding(top = 2.dp))
    }
}

@Composable
fun EarningCalculatorCard(viewModel: ViralViewModel) {
    val views by viewModel.calculatorViews.collectAsState()
    val platform by viewModel.calculatorPlatform.collectAsState()
    val cpm by viewModel.calculatorCpm.collectAsState()

    val platforms = listOf(
        "YouTube (লং ভিডিও)",
        "YouTube (শর্টস)",
        "TikTok (ক্রিয়েটর রিওয়ার্ডস)",
        "Facebook (ইন-স্ট্রিম / রিলস)",
        "AdMob (ব্যানার ও অ্যাপ অ্যাডস)"
    )

    val estimatedUsd = (views / 1000.0) * cpm
    val estimatedBdt = estimatedUsd * 122.5

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .border(1.dp, ElegantDarkBorder, RoundedCornerShape(20.dp)),
        colors = CardDefaults.cardColors(containerColor = ElegantDarkSurface)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Calculate, contentDescription = null, tint = ElegantDarkPrimary, modifier = Modifier.size(20.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(text = "লাইভ ইনকাম প্রজেকশন ক্যালকুলেটর", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = ElegantDarkText)
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Platform selection
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(platforms) { p ->
                    Surface(
                        color = if (platform == p) ElegantDarkPrimary.copy(alpha = 0.2f) else ElegantDarkSurfaceVariant,
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .clickable { viewModel.setCalculatorPlatform(p) }
                            .border(1.dp, if (platform == p) ElegantDarkPrimary else ElegantDarkBorder, RoundedCornerShape(8.dp))
                    ) {
                        Text(
                            text = p,
                            fontSize = 11.sp,
                            fontWeight = if (platform == p) FontWeight.Bold else FontWeight.Normal,
                            color = if (platform == p) ElegantDarkPrimary else ElegantDarkTextMuted,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Slider
            Text(
                text = "সম্ভাব্য ভিউ সংখ্যা: ${NumberFormat.getNumberInstance(Locale.US).format(views)} ভিউ",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = ElegantDarkText
            )

            Slider(
                value = views.toFloat(),
                onValueChange = { viewModel.setCalculatorViews(it.toLong()) },
                valueRange = 5000f..1000000f,
                steps = 19,
                colors = SliderDefaults.colors(
                    thumbColor = ElegantDarkPrimary,
                    activeTrackColor = ElegantDarkPrimary,
                    inactiveTrackColor = ElegantDarkSurfaceVariant
                )
            )

            // Result
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(ElegantDarkAccentGreen.copy(alpha = 0.12f))
                    .padding(12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(text = "সম্ভাব্য আয়:", fontSize = 11.sp, color = ElegantDarkTextMuted)
                    Text(
                        text = "৳" + NumberFormat.getNumberInstance(Locale.US).format(estimatedBdt.toInt()),
                        fontSize = 20.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = ElegantDarkAccentGreen
                    )
                }
                Text(
                    text = "$${String.format(Locale.US, "%.2f", estimatedUsd)} USD",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = ElegantDarkAccentGreen
                )
            }
        }
    }
}

@Composable
fun ViralChecklistCard(viewModel: ViralViewModel) {
    val checklist by viewModel.checklistState.collectAsState()

    val checklistItems = listOf(
        "hook" to "প্রথম ৩ সেকেন্ডে ক্লিফহ্যাঙ্গার বা হুক যুক্ত আছে",
        "trending_sound" to "ব্যাকগ্রাউন্ডে ট্রেন্ডিং অরিজিনাল মিউজিক যোগ করা হয়েছে",
        "caption_cta" to "ক্যাপশনে কমেন্ট ও শেয়ার করার আহ্বান আছে",
        "high_contrast_thumb" to "থাম্বনেইলে হাই-কন্ট্রাস্ট বোল্ড টেক্সট দেওয়া হয়েছে",
        "telegram_share" to "রিলিজের প্রথম ১ ঘণ্টায় টেলিগ্রামে লিংক শেয়ার সম্পন্ন",
        "good_message" to "ভিডিওতে পজিটিভ বা শিক্ষণীয় মেসেজ রয়েছে"
    )

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .border(1.dp, ElegantDarkBorder, RoundedCornerShape(20.dp)),
        colors = CardDefaults.cardColors(containerColor = ElegantDarkSurface)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.CheckCircle, contentDescription = null, tint = ElegantDarkAccentGreen, modifier = Modifier.size(20.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(text = "ভিডিও আপলোডের পূর্ববর্তী ভাইরাল চেকলিস্ট", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = ElegantDarkText)
            }

            Spacer(modifier = Modifier.height(10.dp))

            checklistItems.forEach { (key, label) ->
                val isChecked = checklist[key] ?: false
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { viewModel.toggleChecklistItem(key) }
                        .padding(vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Checkbox(
                        checked = isChecked,
                        onCheckedChange = { viewModel.toggleChecklistItem(key) },
                        colors = CheckboxDefaults.colors(
                            checkedColor = ElegantDarkAccentGreen,
                            uncheckedColor = ElegantDarkBorder
                        )
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = label,
                        fontSize = 12.sp,
                        color = if (isChecked) ElegantDarkText else ElegantDarkTextMuted
                    )
                }
            }
        }
    }
}
