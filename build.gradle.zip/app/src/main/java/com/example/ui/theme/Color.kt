package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Elegant Dark Palette
val ElegantDarkBackground = Color(0xFF111318)
val ElegantDarkSurface = Color(0xFF1D1B20)
val ElegantDarkSurfaceVariant = Color(0xFF2B2930)
val ElegantDarkBorder = Color(0xFF49454F)

val ElegantDarkPrimary = Color(0xFFD0BCFF)
val ElegantDarkOnPrimary = Color(0xFF381E72)
val ElegantDarkPrimaryContainer = Color(0xFF381E72)
val ElegantDarkOnPrimaryContainer = Color(0xFFEADDFF)

val ElegantDarkText = Color(0xFFE2E2E6)
val ElegantDarkTextMuted = Color(0xFF938F99)
val ElegantDarkTextSecondary = Color(0xFF909094)

val ElegantDarkSecondary = Color(0xFFCCC2DC)
val ElegantDarkTertiary = Color(0xFFEFB8C8)
val ElegantDarkAccentGreen = Color(0xFF22C55E)
val ElegantDarkAccentBlue = Color(0xFF24A1DE)
val ElegantDarkAccentRed = Color(0xFFFF0000)
val ElegantDarkAccentFb = Color(0xFF0866FF)

