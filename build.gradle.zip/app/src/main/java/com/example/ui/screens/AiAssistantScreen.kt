package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.EditNote
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.material.icons.filled.Tag
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.PrimaryTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AiChatMessage
import com.example.data.model.GeneratedAiContent
import com.example.data.model.SocialPlatform
import com.example.data.model.TrendingTopicSuggestion
import com.example.ui.ViralViewModel
import com.example.ui.components.AdMobBannerView
import com.example.ui.theme.ElegantDarkAccentGreen
import com.example.ui.theme.ElegantDarkBorder
import com.example.ui.theme.ElegantDarkPrimary
import com.example.ui.theme.ElegantDarkPrimaryContainer
import com.example.ui.theme.ElegantDarkSurface
import com.example.ui.theme.ElegantDarkSurfaceVariant
import com.example.ui.theme.ElegantDarkText
import com.example.ui.theme.ElegantDarkTextMuted
import com.example.ui.theme.ElegantDarkTextSecondary

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AiAssistantScreen(
    viewModel: ViralViewModel,
    bannerAdUnitId: String,
    isTestMode: Boolean,
    modifier: Modifier = Modifier
) {
    var selectedTab by remember { mutableIntStateOf(0) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .testTag("ai_assistant_screen")
    ) {
        // Mode Switcher Tabs
        PrimaryTabRow(
            selectedTabIndex = selectedTab,
            containerColor = ElegantDarkSurface,
            contentColor = ElegantDarkPrimary,
            modifier = Modifier.border(androidx.compose.foundation.BorderStroke(1.dp, ElegantDarkBorder))
        ) {
            Tab(
                selected = selectedTab == 0,
                onClick = { selectedTab = 0 },
                text = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.AutoAwesome, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("কন্টেন্ট জেনারেটর", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    }
                },
                modifier = Modifier.testTag("tab_ai_generator")
            )
            Tab(
                selected = selectedTab == 1,
                onClick = { selectedTab = 1 },
                text = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Chat, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("এআই চ্যাট অ্যাসিস্ট্যান্ট", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    }
                },
                modifier = Modifier.testTag("tab_ai_chat")
            )
        }

        if (selectedTab == 0) {
            AiContentGeneratorStudio(
                viewModel = viewModel,
                bannerAdUnitId = bannerAdUnitId,
                isTestMode = isTestMode
            )
        } else {
            AiChatAssistantView(
                viewModel = viewModel,
                bannerAdUnitId = bannerAdUnitId,
                isTestMode = isTestMode
            )
        }
    }
}

@Composable
fun AiContentGeneratorStudio(
    viewModel: ViralViewModel,
    bannerAdUnitId: String,
    isTestMode: Boolean
) {
    val context = LocalContext.current
    val generatedContent by viewModel.generatedContent.collectAsState()
    val isGenerating by viewModel.isGeneratingContent.collectAsState()

    var customTopic by remember { mutableStateOf("") }
    var selectedPlatform by remember { mutableStateOf("TikTok Lite") }
    var selectedFormat by remember { mutableStateOf("শর্ট ভিডিও চিত্রনাট্য (Script)") }

    val platforms = listOf("TikTok Lite", "YouTube", "Facebook", "Telegram")
    val formats = listOf("শর্ট ভিডিও চিত্রনাট্য (Script)", "ক্যাপশন ও হ্যাশট্যাগ", "৩-সেকেন্ড হুক")

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("ai_generator_column"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Header Card
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(20.dp))
                    .border(1.dp, ElegantDarkBorder, RoundedCornerShape(20.dp))
                    .testTag("ai_studio_header_card"),
                colors = CardDefaults.cardColors(containerColor = ElegantDarkSurface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(44.dp)
                                .clip(CircleShape)
                                .background(ElegantDarkPrimary.copy(alpha = 0.15f))
                                .border(1.dp, ElegantDarkPrimary.copy(alpha = 0.3f), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Movie,
                                contentDescription = null,
                                tint = ElegantDarkPrimary,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "এআই কন্টেন্ট স্টুডিও ২০২৬",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = ElegantDarkText
                            )
                            Text(
                                text = "পজিটিভ, শিক্ষণীয় ও ভাইরাল ভিডিও তৈরি করুন",
                                fontSize = 12.sp,
                                color = ElegantDarkTextMuted
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Surface(
                        color = ElegantDarkAccentGreen.copy(alpha = 0.12f),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.Favorite, contentDescription = null, tint = ElegantDarkAccentGreen, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "১০০% পজিটিভ ও মানবিক সমাজকল্যাণমূলক কন্টেন্ট প্রমোশন চালু",
                                fontSize = 11.sp,
                                color = ElegantDarkAccentGreen,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }
            }
        }

        // Trending Topics Suggestions
        item {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.TrendingUp, contentDescription = null, tint = Color(0xFFFFB300), modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "সাজেস্টেড ট্রেন্ডিং টপিকস (ক্লিক করে বাছাই করুন):",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = ElegantDarkText
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(viewModel.trendingTopicSuggestions) { topic ->
                        TrendingTopicCard(
                            topic = topic,
                            isSelected = customTopic == topic.title,
                            onClick = { customTopic = topic.title }
                        )
                    }
                }
            }
        }

        // Generator Input Form Card
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(20.dp))
                    .border(1.dp, ElegantDarkBorder, RoundedCornerShape(20.dp))
                    .testTag("generator_form_card"),
                colors = CardDefaults.cardColors(containerColor = ElegantDarkSurface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "আপনার বিষয় বা ধারণার নাম লিখুন:",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = ElegantDarkText
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = customTopic,
                        onValueChange = { customTopic = it },
                        placeholder = {
                            Text(
                                "যেমন: চাকমা মিউজিক ভিডিও হুক, ভালো কাজের অনুপ্রেরণা, গ্রামীণ পাহাড়ি রূপ...",
                                fontSize = 12.sp,
                                color = ElegantDarkTextMuted
                            )
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("input_custom_topic"),
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = ElegantDarkPrimary,
                            unfocusedBorderColor = ElegantDarkBorder,
                            focusedTextColor = ElegantDarkText,
                            unfocusedTextColor = ElegantDarkText,
                            focusedContainerColor = ElegantDarkSurfaceVariant,
                            unfocusedContainerColor = ElegantDarkSurfaceVariant
                        )
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    // Platform Selection
                    Text(
                        text = "টার্গেট সোশ্যাল প্ল্যাটফর্ম:",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium,
                        color = ElegantDarkTextMuted
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(platforms) { platform ->
                            FilterChip(
                                selected = selectedPlatform == platform,
                                onClick = { selectedPlatform = platform },
                                label = { Text(platform, fontSize = 12.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = ElegantDarkPrimary,
                                    selectedLabelColor = Color(0xFF381E72),
                                    containerColor = ElegantDarkSurfaceVariant,
                                    labelColor = ElegantDarkTextMuted
                                )
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Format Selection
                    Text(
                        text = "কন্টেন্ট ফরম্যাট:",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium,
                        color = ElegantDarkTextMuted
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(formats) { format ->
                            FilterChip(
                                selected = selectedFormat == format,
                                onClick = { selectedFormat = format },
                                label = { Text(format, fontSize = 12.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = ElegantDarkAccentGreen.copy(alpha = 0.25f),
                                    selectedLabelColor = ElegantDarkAccentGreen,
                                    containerColor = ElegantDarkSurfaceVariant,
                                    labelColor = ElegantDarkTextMuted
                                )
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Generate Action Button
                    Button(
                        onClick = {
                            val topicToUse = customTopic.ifBlank { "চাকমা মিউজিক ভিডিও এবং ভালো কাজের পজিটিভ ভাইরাল হুক" }
                            viewModel.generateContentWithAi(
                                topic = topicToUse,
                                platformName = selectedPlatform,
                                formatType = selectedFormat
                            )
                        },
                        enabled = !isGenerating,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("btn_generate_content"),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = ElegantDarkPrimary,
                            contentColor = Color(0xFF381E72)
                        ),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        if (isGenerating) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(20.dp),
                                color = Color(0xFF381E72),
                                strokeWidth = 2.dp
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("এআই দিয়ে কন্টেন্ট জেনারেট হচ্ছে...", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        } else {
                            Icon(Icons.Default.AutoAwesome, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("এআই কন্টেন্ট তৈরি করুন", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // Generated Result Card
        if (generatedContent != null) {
            item {
                GeneratedResultCard(
                    content = generatedContent!!,
                    onDirectShare = { platform ->
                        viewModel.shareDirectToPlatform(
                            context = context,
                            platform = platform,
                            caption = "${generatedContent!!.caption}\n\n${generatedContent!!.hook}",
                            hashtags = generatedContent!!.hashtags
                        )
                    },
                    onCopy = {
                        val fullPackage = "🔥 হুক: ${generatedContent!!.hook}\n\n🎬 চিত্রনাট্য:\n${generatedContent!!.videoScript}\n\n📝 ক্যাপশন:\n${generatedContent!!.caption}\n\n🏷️ হ্যাশট্যাগ:\n${generatedContent!!.hashtags}"
                        viewModel.copyToClipboard(context, "Generated Script", fullPackage)
                    }
                )
            }
        }

        // Live Banner
        item {
            Spacer(modifier = Modifier.height(8.dp))
            AdMobBannerView(adUnitId = bannerAdUnitId, isTestMode = isTestMode)
        }
    }
}

@Composable
fun TrendingTopicCard(
    topic: TrendingTopicSuggestion,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .width(240.dp)
            .clip(RoundedCornerShape(16.dp))
            .border(
                1.dp,
                if (isSelected) ElegantDarkPrimary else ElegantDarkBorder,
                RoundedCornerShape(16.dp)
            )
            .clickable { onClick() }
            .testTag("trend_chip_${topic.id}"),
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) ElegantDarkSurfaceVariant else ElegantDarkSurface
        )
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    color = ElegantDarkPrimary.copy(alpha = 0.15f),
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Text(
                        text = topic.category,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = ElegantDarkPrimary,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }

                Text(
                    text = topic.viralPotential,
                    fontSize = 10.sp,
                    color = ElegantDarkAccentGreen,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = topic.title,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = ElegantDarkText,
                lineHeight = 16.sp
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = topic.positiveAngle,
                fontSize = 10.sp,
                color = ElegantDarkTextMuted,
                lineHeight = 14.sp
            )
        }
    }
}

@Composable
fun GeneratedResultCard(
    content: GeneratedAiContent,
    onDirectShare: (SocialPlatform) -> Unit,
    onCopy: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(22.dp))
            .border(1.dp, ElegantDarkPrimary.copy(alpha = 0.4f), RoundedCornerShape(22.dp))
            .testTag("generated_ai_result_card"),
        colors = CardDefaults.cardColors(containerColor = ElegantDarkSurface)
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            // Header with Impact Score
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = ElegantDarkAccentGreen, modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "এআই জেনারেটেড কন্টেন্ট রেজাল্ট",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = ElegantDarkText
                    )
                }

                Surface(
                    color = ElegantDarkAccentGreen.copy(alpha = 0.15f),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Favorite, contentDescription = null, tint = ElegantDarkAccentGreen, modifier = Modifier.size(12.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "${content.positiveImpactScore}% পজিটিভ ইমপ্যাক্ট",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = ElegantDarkAccentGreen
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // 1. Hook Section
            SectionHeader(icon = Icons.Default.FlashOn, title = "৩-সেকেন্ড পাওয়ারফুল হুক:", color = Color(0xFFFFB300))
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(Color(0xFFFFB300).copy(alpha = 0.1f))
                    .padding(10.dp)
            ) {
                Text(text = content.hook, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = ElegantDarkText)
            }

            Spacer(modifier = Modifier.height(12.dp))

            // 2. Video Script
            SectionHeader(icon = Icons.Default.Movie, title = "শর্ট ভিডিও স্ক্রিপ্ট ও ভিজ্যুয়াল ডিরেকশন:", color = ElegantDarkPrimary)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(ElegantDarkSurfaceVariant)
                    .padding(12.dp)
            ) {
                Text(text = content.videoScript, fontSize = 12.sp, color = ElegantDarkTextSecondary, lineHeight = 18.sp)
            }

            Spacer(modifier = Modifier.height(12.dp))

            // 3. Caption & CTA
            SectionHeader(icon = Icons.Default.EditNote, title = "ক্যাপশন ও কল-টু-অ্যাকশন (CTA):", color = Color(0xFF64B5F6))
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(ElegantDarkSurfaceVariant)
                    .padding(12.dp)
            ) {
                Text(text = content.caption, fontSize = 12.sp, color = ElegantDarkText, lineHeight = 18.sp)
            }

            Spacer(modifier = Modifier.height(12.dp))

            // 4. Hashtags
            SectionHeader(icon = Icons.Default.Tag, title = "ভাইরাল হ্যাশট্যাগ বান্ডল:", color = Color(0xFFFF0050))
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(Color(0xFFFF0050).copy(alpha = 0.1f))
                    .padding(10.dp)
            ) {
                Text(text = content.hashtags, fontSize = 12.sp, color = Color(0xFFFF80AB), fontWeight = FontWeight.Medium)
            }

            Spacer(modifier = Modifier.height(16.dp))
            HorizontalDivider(color = ElegantDarkBorder, thickness = 1.dp)
            Spacer(modifier = Modifier.height(14.dp))

            // Direct Multi-Platform Sharing Actions
            Text(
                text = "সরাসরি সোশ্যাল মিডিয়ায় শেয়ার করুন:",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = ElegantDarkTextMuted
            )

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                SharePlatformButton(
                    label = "TikTok",
                    color = Color(0xFFFF0050),
                    modifier = Modifier.weight(1f),
                    onClick = { onDirectShare(SocialPlatform.TIKTOK) }
                )
                SharePlatformButton(
                    label = "YouTube",
                    color = Color(0xFFFF0000),
                    modifier = Modifier.weight(1f),
                    onClick = { onDirectShare(SocialPlatform.YOUTUBE) }
                )
                SharePlatformButton(
                    label = "Facebook",
                    color = Color(0xFF1877F2),
                    modifier = Modifier.weight(1f),
                    onClick = { onDirectShare(SocialPlatform.FACEBOOK) }
                )
                SharePlatformButton(
                    label = "Telegram",
                    color = Color(0xFF2AABEE),
                    modifier = Modifier.weight(1f),
                    onClick = { onDirectShare(SocialPlatform.TELEGRAM) }
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            OutlinedButton(
                onClick = onCopy,
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, ElegantDarkBorder)
            ) {
                Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp), tint = ElegantDarkText)
                Spacer(modifier = Modifier.width(6.dp))
                Text("সম্পূর্ণ প্যাকেজ কপি করুন", fontSize = 12.sp, color = ElegantDarkText, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun SectionHeader(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, color: Color) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.padding(bottom = 6.dp)
    ) {
        Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(16.dp))
        Spacer(modifier = Modifier.width(6.dp))
        Text(text = title, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = color)
    }
}

@Composable
fun SharePlatformButton(
    label: String,
    color: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Button(
        onClick = onClick,
        modifier = modifier,
        colors = ButtonDefaults.buttonColors(
            containerColor = color.copy(alpha = 0.15f),
            contentColor = color
        ),
        shape = RoundedCornerShape(10.dp),
        contentPadding = PaddingValues(horizontal = 6.dp, vertical = 8.dp)
    ) {
        Text(text = label, fontSize = 11.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun AiChatAssistantView(
    viewModel: ViralViewModel,
    bannerAdUnitId: String,
    isTestMode: Boolean
) {
    val context = LocalContext.current
    val chatMessages by viewModel.chatMessages.collectAsState()
    val isAiLoading by viewModel.isAiLoading.collectAsState()
    var promptInput by remember { mutableStateOf("") }
    val listState = rememberLazyListState()

    val suggestedPrompts = listOf(
        "🎶 চাকমা মিউজিক ভিডিও ভাইরাল করার ৫টি হুক",
        "🌟 ভালো কাজের পজিটিভ ভিডিও আইডিয়া",
        "💰 বিকাশ/নগদে টাকা উইথড্র করার নিয়ম কী?",
        "🚀 টিকটকে ১০০K ভিউ পাওয়ার সিক্রেট স্ক্রিপ্ট",
        "🏷️ ইউটিউব ও রিলস এর জন্য ট্রেন্ডিং ট্যাগস"
    )

    LaunchedEffect(chatMessages.size) {
        if (chatMessages.isNotEmpty()) {
            listState.animateScrollToItem(chatMessages.size - 1)
        }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        // Suggested Prompts Row
        LazyRow(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(suggestedPrompts) { prompt ->
                Surface(
                    color = ElegantDarkSurfaceVariant,
                    shape = RoundedCornerShape(20.dp),
                    modifier = Modifier
                        .clickable { viewModel.sendAiPrompt(prompt) }
                        .border(1.dp, ElegantDarkBorder, RoundedCornerShape(20.dp))
                ) {
                    Text(
                        text = prompt,
                        fontSize = 11.sp,
                        color = ElegantDarkText,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                    )
                }
            }
        }

        // Messages List
        LazyColumn(
            state = listState,
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(horizontal = 12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(chatMessages) { message ->
                ChatMessageBubble(
                    message = message,
                    onCopy = { viewModel.copyToClipboard(context, "AI Response", message.text) },
                    onShare = { viewModel.shareText(context, "AI Creator Assistant", message.text) }
                )
            }

            if (isAiLoading) {
                item {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(8.dp)
                    ) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(16.dp),
                            color = ElegantDarkPrimary,
                            strokeWidth = 2.dp
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "এআই চিন্তা করছে ও পরামর্শ তৈরি করছে...",
                            fontSize = 12.sp,
                            color = ElegantDarkTextMuted
                        )
                    }
                }
            }
        }

        // Input Bar
        Surface(
            color = ElegantDarkSurface,
            modifier = Modifier
                .fillMaxWidth()
                .border(androidx.compose.foundation.BorderStroke(1.dp, ElegantDarkBorder))
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = promptInput,
                    onValueChange = { promptInput = it },
                    placeholder = { Text("আপনার প্রশ্ন বা টপিক লিখুন...", fontSize = 13.sp, color = ElegantDarkTextMuted) },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("chat_input_field"),
                    shape = RoundedCornerShape(20.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = ElegantDarkPrimary,
                        unfocusedBorderColor = ElegantDarkBorder,
                        focusedTextColor = ElegantDarkText,
                        unfocusedTextColor = ElegantDarkText,
                        focusedContainerColor = ElegantDarkSurfaceVariant,
                        unfocusedContainerColor = ElegantDarkSurfaceVariant
                    ),
                    maxLines = 3
                )

                Spacer(modifier = Modifier.width(8.dp))

                IconButton(
                    onClick = {
                        if (promptInput.isNotBlank()) {
                            viewModel.sendAiPrompt(promptInput)
                            promptInput = ""
                        }
                    },
                    modifier = Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .background(ElegantDarkPrimary)
                        .testTag("chat_send_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.Send,
                        contentDescription = "Send",
                        tint = Color(0xFF381E72),
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun ChatMessageBubble(
    message: AiChatMessage,
    onCopy: () -> Unit,
    onShare: () -> Unit
) {
    val isUser = message.isUser

    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = if (isUser) Alignment.End else Alignment.Start
    ) {
        Row(
            verticalAlignment = Alignment.Top,
            horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start,
            modifier = Modifier.fillMaxWidth(0.92f)
        ) {
            if (!isUser) {
                Box(
                    modifier = Modifier
                        .size(32.dp)
                        .clip(CircleShape)
                        .background(ElegantDarkPrimary.copy(alpha = 0.2f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.SmartToy, contentDescription = null, tint = ElegantDarkPrimary, modifier = Modifier.size(18.dp))
                }
                Spacer(modifier = Modifier.width(8.dp))
            }

            Surface(
                color = if (isUser) ElegantDarkPrimaryContainer else ElegantDarkSurface,
                shape = RoundedCornerShape(
                    topStart = 16.dp,
                    topEnd = 16.dp,
                    bottomStart = if (isUser) 16.dp else 4.dp,
                    bottomEnd = if (isUser) 4.dp else 16.dp
                ),
                modifier = Modifier.border(1.dp, ElegantDarkBorder, RoundedCornerShape(16.dp))
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(
                        text = message.text,
                        fontSize = 13.sp,
                        color = ElegantDarkText,
                        lineHeight = 19.sp
                    )

                    if (!isUser) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            horizontalArrangement = Arrangement.End,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            IconButton(onClick = onCopy, modifier = Modifier.size(24.dp)) {
                                Icon(Icons.Default.ContentCopy, contentDescription = "Copy", tint = ElegantDarkTextMuted, modifier = Modifier.size(14.dp))
                            }
                            Spacer(modifier = Modifier.width(6.dp))
                            IconButton(onClick = onShare, modifier = Modifier.size(24.dp)) {
                                Icon(Icons.Default.Share, contentDescription = "Share", tint = ElegantDarkTextMuted, modifier = Modifier.size(14.dp))
                            }
                        }
                    }
                }
            }

            if (isUser) {
                Spacer(modifier = Modifier.width(8.dp))
                Box(
                    modifier = Modifier
                        .size(32.dp)
                        .clip(CircleShape)
                        .background(ElegantDarkPrimary),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.Person, contentDescription = null, tint = Color(0xFF381E72), modifier = Modifier.size(18.dp))
                }
            }
        }
    }
}
